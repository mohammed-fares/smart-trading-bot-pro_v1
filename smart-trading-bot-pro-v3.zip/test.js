const TradingEngine = require('./src/core/TradingEngine');
const StrategyFactory = require('./src/strategies/StrategyFactory');
const logger = require('./src/utils/Logger');

async function test() {
    console.log('🧪 Testing Trading Engine...');

    const engine = new TradingEngine();
    const strategy = StrategyFactory.create('RSI_EMA_MACD');
    engine.setStrategy(strategy);
    engine.setTradingPair('BTCUSDT');
    engine.setTimeframe('1h');

    // Mock price update callback
    engine.setCallbacks(
        (type, trade) => {
            console.log(`📈 Trade ${type}:`, trade.symbol, trade.direction, trade.entryPrice);
        },
        (stats) => {
            console.log('📊 Stats:', {
                balance: stats.paperBalance,
                equity: stats.equity,
                openTrades: stats.openTradesCount
            });
        }
    );

    console.log('✅ Engine initialized successfully!');
    console.log('Strategy:', strategy.name);
    console.log('Pair:', engine.tradingPair);
    console.log('Timeframe:', engine.timeframe);
    console.log('Initial Balance:', engine.paperBalance);

    process.exit(0);
}

test().catch(err => {
    console.error('❌ Test failed:', err);
    process.exit(1);
});
