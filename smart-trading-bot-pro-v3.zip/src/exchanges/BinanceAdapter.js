const axios = require('axios');
const WebSocket = require('ws');
const logger = require('../utils/Logger');
const config = require('../../config/default.json');

class BinanceAdapter {
    constructor(marketType = 'spot') {
        this.marketType = marketType;

        if (marketType === 'futures') {
            this.baseURL = config.binance.futuresApiUrl;
            this.wsURL = config.binance.futuresWsUrl;
        } else {
            this.baseURL = config.binance.spotApiUrl;
            this.wsURL = config.binance.spotWsUrl;
        }

        this.apiKey = process.env.BINANCE_API_KEY;
        this.apiSecret = process.env.BINANCE_SECRET_KEY;
        this.wsConnections = new Map();
        this.priceCallbacks = new Map();
        this.klineCallbacks = new Map();

        logger.info(`Binance adapter initialized for ${marketType.toUpperCase()} market`);
    }

    setMarketType(type) {
        if (type !== this.marketType) {
            this.disconnectAll();
            this.marketType = type;

            if (type === 'futures') {
                this.baseURL = config.binance.futuresApiUrl;
                this.wsURL = config.binance.futuresWsUrl;
            } else {
                this.baseURL = config.binance.spotApiUrl;
                this.wsURL = config.binance.spotWsUrl;
            }

            logger.info(`Market type switched to ${type.toUpperCase()}`);
        }
    }

    async getKlines(symbol, interval, limit = 100) {
        try {
            const endpoint = this.marketType === 'futures' ? '/fapi/v1/klines' : '/api/v3/klines';
            const response = await axios.get(`${this.baseURL}${endpoint}`, {
                params: { symbol, interval, limit },
                timeout: 10000
            });

            return response.data.map(k => ({
                timestamp: k[0],
                open: parseFloat(k[1]),
                high: parseFloat(k[2]),
                low: parseFloat(k[3]),
                close: parseFloat(k[4]),
                volume: parseFloat(k[5]),
                closeTime: k[6],
                quoteVolume: parseFloat(k[7] || 0),
                trades: parseInt(k[8] || 0)
            }));
        } catch (error) {
            logger.error(`Error fetching klines for ${symbol}:`, error.message);
            throw error;
        }
    }

    async getTicker(symbol) {
        try {
            const endpoint = this.marketType === 'futures' ? '/fapi/v1/ticker/24hr' : '/api/v3/ticker/24hr';
            const response = await axios.get(`${this.baseURL}${endpoint}`, {
                params: { symbol },
                timeout: 5000
            });
            return {
                symbol: response.data.symbol,
                price: parseFloat(response.data.lastPrice),
                change24h: parseFloat(response.data.priceChangePercent),
                high24h: parseFloat(response.data.highPrice),
                low24h: parseFloat(response.data.lowPrice),
                volume24h: parseFloat(response.data.volume),
                quoteVolume: parseFloat(response.data.quoteVolume),
                marketType: this.marketType
            };
        } catch (error) {
            logger.error(`Error fetching ticker for ${symbol}:`, error.message);
            throw error;
        }
    }

    async getExchangeInfo() {
        try {
            const endpoint = this.marketType === 'futures' ? '/fapi/v1/exchangeInfo' : '/api/v3/exchangeInfo';
            const response = await axios.get(`${this.baseURL}${endpoint}`, {
                timeout: 10000
            });

            if (this.marketType === 'futures') {
                return response.data.symbols.filter(s => s.status === 'TRADING');
            } else {
                return response.data.symbols.filter(s => s.status === 'TRADING');
            }
        } catch (error) {
            logger.error('Error fetching exchange info:', error.message);
            throw error;
        }
    }

    async getFundingRate(symbol) {
        if (this.marketType !== 'futures') {
            return null;
        }

        try {
            const response = await axios.get(`${this.baseURL}/fapi/v1/fundingRate`, {
                params: { symbol, limit: 1 },
                timeout: 5000
            });

            if (response.data && response.data.length > 0) {
                return {
                    fundingRate: parseFloat(response.data[0].fundingRate),
                    fundingTime: response.data[0].fundingTime
                };
            }
            return null;
        } catch (error) {
            logger.error('Error fetching funding rate:', error.message);
            return null;
        }
    }

    async getOpenInterest(symbol) {
        if (this.marketType !== 'futures') {
            return null;
        }

        try {
            const response = await axios.get(`${this.baseURL}/fapi/v1/openInterest`, {
                params: { symbol },
                timeout: 5000
            });

            return {
                openInterest: parseFloat(response.data.openInterest),
                time: response.data.time
            };
        } catch (error) {
            logger.error('Error fetching open interest:', error.message);
            return null;
        }
    }

    subscribeToPrice(symbol, callback) {
        const stream = `${symbol.toLowerCase()}@ticker`;
        const wsUrl = `${this.wsURL}/${stream}`;

        if (this.wsConnections.has(stream)) {
            this.priceCallbacks.set(symbol, callback);
            return;
        }

        const ws = new WebSocket(wsUrl);

        ws.on('open', () => {
            logger.info(`WebSocket connected for ${symbol} price (${this.marketType})`);
        });

        ws.on('message', (data) => {
            try {
                const ticker = JSON.parse(data);
                const priceData = {
                    symbol: ticker.s,
                    price: parseFloat(ticker.c),
                    change24h: parseFloat(ticker.P),
                    high24h: parseFloat(ticker.h),
                    low24h: parseFloat(ticker.l),
                    volume24h: parseFloat(ticker.v),
                    timestamp: ticker.E,
                    marketType: this.marketType
                };

                if (this.priceCallbacks.has(symbol)) {
                    this.priceCallbacks.get(symbol)(priceData);
                }
            } catch (error) {
                logger.error('Error parsing WebSocket message:', error);
            }
        });

        ws.on('error', (error) => {
            logger.error(`WebSocket error for ${symbol}:`, error.message);
        });

        ws.on('close', () => {
            logger.warn(`WebSocket closed for ${symbol}, reconnecting...`);
            setTimeout(() => this.subscribeToPrice(symbol, callback), 5000);
        });

        this.wsConnections.set(stream, ws);
        this.priceCallbacks.set(symbol, callback);
    }

    subscribeToKlines(symbol, interval, callback) {
        const stream = `${symbol.toLowerCase()}@kline_${interval}`;
        const wsUrl = `${this.wsURL}/${stream}`;

        if (this.wsConnections.has(stream)) {
            this.klineCallbacks.set(`${symbol}_${interval}`, callback);
            return;
        }

        const ws = new WebSocket(wsUrl);

        ws.on('open', () => {
            logger.info(`WebSocket connected for ${symbol} klines (${interval}) - ${this.marketType}`);
        });

        ws.on('message', (data) => {
            try {
                const kline = JSON.parse(data).k;
                const candleData = {
                    timestamp: kline.t,
                    open: parseFloat(kline.o),
                    high: parseFloat(kline.h),
                    low: parseFloat(kline.l),
                    close: parseFloat(kline.c),
                    volume: parseFloat(kline.v),
                    isClosed: kline.x,
                    marketType: this.marketType
                };

                if (this.klineCallbacks.has(`${symbol}_${interval}`)) {
                    this.klineCallbacks.get(`${symbol}_${interval}`)(candleData);
                }
            } catch (error) {
                logger.error('Error parsing kline message:', error);
            }
        });

        ws.on('error', (error) => {
            logger.error(`Kline WebSocket error for ${symbol}:`, error.message);
        });

        ws.on('close', () => {
            logger.warn(`Kline WebSocket closed for ${symbol}, reconnecting...`);
            setTimeout(() => this.subscribeToKlines(symbol, interval, callback), 5000);
        });

        this.wsConnections.set(stream, ws);
        this.klineCallbacks.set(`${symbol}_${interval}`, callback);
    }

    unsubscribe(symbol, interval = null) {
        const streams = interval 
            ? [`${symbol.toLowerCase()}@ticker`, `${symbol.toLowerCase()}@kline_${interval}`]
            : [`${symbol.toLowerCase()}@ticker`];

        streams.forEach(stream => {
            if (this.wsConnections.has(stream)) {
                this.wsConnections.get(stream).close();
                this.wsConnections.delete(stream);
            }
        });

        this.priceCallbacks.delete(symbol);
        if (interval) {
            this.klineCallbacks.delete(`${symbol}_${interval}`);
        }
    }

    disconnectAll() {
        this.wsConnections.forEach((ws, stream) => {
            ws.close();
            logger.info(`Disconnected from ${stream}`);
        });
        this.wsConnections.clear();
        this.priceCallbacks.clear();
        this.klineCallbacks.clear();
    }
}

module.exports = BinanceAdapter;