const { BollingerBands, RSI, ATR, EMA, VolumeProfile } = require('technicalindicators');
const logger = require('../utils/Logger');

class BollingerBreakoutStrategy {
    constructor() {
        this.name = 'BOLLINGER_BREAKOUT';
        this.bbPeriod = 20;
        this.bbStdDev = 2.5;
        this.rsiPeriod = 14;
        this.atrPeriod = 14;
        this.emaPeriod = 50;
        this.volumePeriod = 20;
    }

    analyze(candles) {
        try {
            if (candles.length < 60) {
                return { signal: 'HOLD', confidence: 0, reason: 'Insufficient data' };
            }

            const closes = candles.map(c => c.close);
            const highs = candles.map(c => c.high);
            const lows = candles.map(c => c.low);
            const volumes = candles.map(c => c.volume);
            const opens = candles.map(c => c.open);

            const currentPrice = closes[closes.length - 1];
            const currentHigh = highs[highs.length - 1];
            const currentLow = lows[lows.length - 1];
            const currentOpen = opens[opens.length - 1];
            const currentVolume = volumes[volumes.length - 1];
            const previousClose = closes[closes.length - 2];

            // Calculate indicators
            const bbValues = BollingerBands.calculate({
                period: this.bbPeriod,
                values: closes,
                stdDev: this.bbStdDev
            });

            const rsiValues = RSI.calculate({ values: closes, period: this.rsiPeriod });
            const atrValues = ATR.calculate({
                high: highs,
                low: lows,
                close: closes,
                period: this.atrPeriod
            });
            const emaValues = EMA.calculate({ values: closes, period: this.emaPeriod });

            const lastBB = bbValues[bbValues.length - 1];
            const prevBB = bbValues[bbValues.length - 2];
            const lastRSI = rsiValues[rsiValues.length - 1];
            const prevRSI = rsiValues[rsiValues.length - 2];
            const lastATR = atrValues[atrValues.length - 1];
            const lastEMA = emaValues[emaValues.length - 1];

            // Volume analysis
            const avgVolume = volumes.slice(-this.volumePeriod).reduce((a, b) => a + b, 0) / this.volumePeriod;
            const volumeRatio = currentVolume / avgVolume;

            // Bollinger Band width (volatility)
            const bbWidth = (lastBB.upper - lastBB.lower) / lastBB.middle * 100;
            const prevBBWidth = (prevBB.upper - prevBB.lower) / prevBB.middle * 100;

            // Squeeze detection (low volatility before breakout)
            const isSqueeze = bbWidth < prevBBWidth && bbWidth < 2.0;
            const wasSqueeze = prevBBWidth < 2.0;

            // Scoring
            let buyScore = 0;
            let sellScore = 0;
            let reasons = [];

            // === BUY SIGNALS ===
            // 1. Price breaks above upper band with volume
            if (currentHigh > lastBB.upper && volumeRatio > 1.3) {
                buyScore += 30;
                reasons.push('Price broke above upper Bollinger Band with volume');
            }

            // 2. Squeeze breakout (low volatility -> high volatility)
            if (wasSqueeze && bbWidth > prevBBWidth && currentPrice > previousClose) {
                buyScore += 25;
                reasons.push('Bollinger Squeeze breakout to upside');
            }

            // 3. Price bounces from lower band
            if (previousClose <= prevBB.lower && currentPrice > lastBB.lower && currentPrice > previousClose) {
                buyScore += 20;
                reasons.push('Bounce from lower Bollinger Band');
            }

            // 4. RSI confirmation (not overbought)
            if (lastRSI > 50 && lastRSI < 70 && prevRSI < lastRSI) {
                buyScore += 15;
                reasons.push('RSI bullish momentum');
            }

            // 5. Price above EMA (trend confirmation)
            if (currentPrice > lastEMA) {
                buyScore += 10;
                reasons.push('Price above EMA trend');
            }

            // === SELL SIGNALS ===
            // 1. Price breaks below lower band with volume
            if (currentLow < lastBB.lower && volumeRatio > 1.3) {
                sellScore += 30;
                reasons.push('Price broke below lower Bollinger Band with volume');
            }

            // 2. Squeeze breakout to downside
            if (wasSqueeze && bbWidth > prevBBWidth && currentPrice < previousClose) {
                sellScore += 25;
                reasons.push('Bollinger Squeeze breakout to downside');
            }

            // 3. Price rejected from upper band
            if (previousClose >= prevBB.upper && currentPrice < lastBB.upper && currentPrice < previousClose) {
                sellScore += 20;
                reasons.push('Rejection from upper Bollinger Band');
            }

            // 4. RSI confirmation (not oversold)
            if (lastRSI < 50 && lastRSI > 30 && prevRSI > lastRSI) {
                sellScore += 15;
                reasons.push('RSI bearish momentum');
            }

            // 5. Price below EMA
            if (currentPrice < lastEMA) {
                sellScore += 10;
                reasons.push('Price below EMA trend');
            }

            // === FILTERS ===
            // Avoid trading in extremely low volatility
            if (bbWidth < 1.0) {
                buyScore = 0;
                sellScore = 0;
                reasons.push('Extremely low volatility - waiting for expansion');
            }

            // Avoid if RSI is in extreme zones
            if (lastRSI > 75 && buyScore > 0) {
                buyScore *= 0.5;
                reasons.push('RSI very high - reducing buy confidence');
            }
            if (lastRSI < 25 && sellScore > 0) {
                sellScore *= 0.5;
                reasons.push('RSI very low - reducing sell confidence');
            }

            // Determine signal
            let signal = 'HOLD';
            let confidence = 0;

            const threshold = 45;

            if (buyScore >= threshold && buyScore > sellScore) {
                signal = 'BUY';
                confidence = Math.min(buyScore / 100, 0.95);
            } else if (sellScore >= threshold && sellScore > buyScore) {
                signal = 'SELL';
                confidence = Math.min(sellScore / 100, 0.95);
            }

            return {
                signal,
                confidence,
                reasons,
                indicators: {
                    bbUpper: lastBB.upper,
                    bbMiddle: lastBB.middle,
                    bbLower: lastBB.lower,
                    bbWidth,
                    isSqueeze,
                    rsi: lastRSI,
                    atr: lastATR,
                    ema: lastEMA,
                    volumeRatio,
                    trend: currentPrice > lastEMA ? 'UP' : 'DOWN'
                }
            };

        } catch (error) {
            logger.error('Bollinger strategy error:', error);
            return { signal: 'HOLD', confidence: 0, reason: 'Analysis error' };
        }
    }
}

module.exports = BollingerBreakoutStrategy;