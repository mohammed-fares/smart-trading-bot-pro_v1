const RSI_EMA_MACD_Strategy = require('./RSI_EMA_MACD_Strategy');
const BollingerBreakoutStrategy = require('./BollingerBreakoutStrategy');
const logger = require('../utils/Logger');

class StrategyFactory {
    static create(strategyName) {
        switch(strategyName) {
            case 'RSI_EMA_MACD':
                return new RSI_EMA_MACD_Strategy();
            case 'BOLLINGER_BREAKOUT':
                return new BollingerBreakoutStrategy();
            default:
                logger.warn(`Unknown strategy: ${strategyName}, using default RSI_EMA_MACD`);
                return new RSI_EMA_MACD_Strategy();
        }
    }

    static getAvailableStrategies() {
        return [
            {
                name: 'RSI_EMA_MACD',
                description: 'Multi-indicator strategy using RSI, EMA crossover, and MACD',
                indicators: ['RSI(14)', 'EMA(12/26)', 'MACD(12,26,9)', 'Bollinger Bands(20,2)', 'ATR(14)']
            },
            {
                name: 'BOLLINGER_BREAKOUT',
                description: 'Bollinger Band squeeze and breakout strategy',
                indicators: ['Bollinger Bands(20,2.5)', 'RSI(14)', 'EMA(50)', 'ATR(14)', 'Volume Analysis']
            }
        ];
    }
}

module.exports = StrategyFactory;