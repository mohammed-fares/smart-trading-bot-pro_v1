const { RSI, EMA, MACD, ATR, BollingerBands } = require('technicalindicators');
const logger = require('../utils/Logger');

class RSI_EMA_MACD_Strategy {
    constructor() {
        this.name = 'RSI_EMA_MACD';
        this.rsiPeriod = 14;
        this.emaFast = 12;
        this.emaSlow = 26;
        this.macdFast = 12;
        this.macdSlow = 26;
        this.macdSignal = 9;
        this.bbPeriod = 20;
        this.bbStdDev = 2;
        this.atrPeriod = 14;
    }

    analyze(candles) {
        try {
            if (candles.length < 50) {
                return { signal: 'HOLD', confidence: 0, reason: 'Insufficient data' };
            }

            const closes = candles.map(c => c.close);
            const highs = candles.map(c => c.high);
            const lows = candles.map(c => c.low);
            const volumes = candles.map(c => c.volume);
            const currentPrice = closes[closes.length - 1];
            const previousPrice = closes[closes.length - 2];

            // Calculate indicators
            const rsiValues = RSI.calculate({ values: closes, period: this.rsiPeriod });
            const emaFastValues = EMA.calculate({ values: closes, period: this.emaFast });
            const emaSlowValues = EMA.calculate({ values: closes, period: this.emaSlow });
            const macdValues = MACD.calculate({
                values: closes,
                fastPeriod: this.macdFast,
                slowPeriod: this.macdSlow,
                signalPeriod: this.macdSignal,
                SimpleMAOscillator: false,
                SimpleMASignal: false
            });
            const bbValues = BollingerBands.calculate({
                period: this.bbPeriod,
                values: closes,
                stdDev: this.bbStdDev
            });
            const atrValues = ATR.calculate({
                high: highs,
                low: lows,
                close: closes,
                period: this.atrPeriod
            });

            const lastRSI = rsiValues[rsiValues.length - 1];
            const prevRSI = rsiValues[rsiValues.length - 2];
            const lastEMAFast = emaFastValues[emaFastValues.length - 1];
            const lastEMASlow = emaSlowValues[emaSlowValues.length - 1];
            const prevEMAFast = emaFastValues[emaFastValues.length - 2];
            const prevEMASlow = emaSlowValues[emaSlowValues.length - 2];
            const lastMACD = macdValues[macdValues.length - 1];
            const prevMACD = macdValues[macdValues.length - 2];
            const lastBB = bbValues[bbValues.length - 1];
            const lastATR = atrValues[atrValues.length - 1];

            // Volume analysis
            const avgVolume = volumes.slice(-20).reduce((a, b) => a + b, 0) / 20;
            const currentVolume = volumes[volumes.length - 1];
            const volumeRatio = currentVolume / avgVolume;

            // Trend strength
            const trendStrength = Math.abs(lastEMAFast - lastEMASlow) / lastEMASlow * 100;

            // Scoring system
            let buyScore = 0;
            let sellScore = 0;
            let reasons = [];

            // RSI Analysis
            if (lastRSI < 30 && prevRSI < lastRSI) {
                buyScore += 25;
                reasons.push('RSI oversold and rising');
            } else if (lastRSI > 70 && prevRSI > lastRSI) {
                sellScore += 25;
                reasons.push('RSI overbought and falling');
            }

            // EMA Crossover
            if (prevEMAFast <= prevEMASlow && lastEMAFast > lastEMASlow) {
                buyScore += 30;
                reasons.push('EMA Golden Cross');
            } else if (prevEMAFast >= prevEMASlow && lastEMAFast < lastEMASlow) {
                sellScore += 30;
                reasons.push('EMA Death Cross');
            }

            // MACD Analysis
            if (prevMACD.MACD <= prevMACD.signal && lastMACD.MACD > lastMACD.signal) {
                buyScore += 25;
                reasons.push('MACD bullish crossover');
            } else if (prevMACD.MACD >= prevMACD.signal && lastMACD.MACD < lastMACD.signal) {
                sellScore += 25;
                reasons.push('MACD bearish crossover');
            }

            // Bollinger Bands
            if (currentPrice <= lastBB.lower && lastRSI < 40) {
                buyScore += 15;
                reasons.push('Price at lower Bollinger Band');
            } else if (currentPrice >= lastBB.upper && lastRSI > 60) {
                sellScore += 15;
                reasons.push('Price at upper Bollinger Band');
            }

            // Volume confirmation
            if (volumeRatio > 1.5) {
                if (buyScore > sellScore) buyScore += 5;
                else if (sellScore > buyScore) sellScore += 5;
                reasons.push('High volume confirmation');
            }

            // Trend filter
            if (trendStrength > 0.5) {
                if (lastEMAFast > lastEMASlow) {
                    buyScore += 5;
                } else {
                    sellScore += 5;
                }
            }

            // Determine signal
            let signal = 'HOLD';
            let confidence = 0;

            if (buyScore >= 50 && buyScore > sellScore) {
                signal = 'BUY';
                confidence = Math.min(buyScore / 100, 0.95);
            } else if (sellScore >= 50 && sellScore > buyScore) {
                signal = 'SELL';
                confidence = Math.min(sellScore / 100, 0.95);
            }

            // Additional checks
            if (signal !== 'HOLD') {
                // Avoid trading in low volatility
                if (lastATR / currentPrice < 0.001) {
                    signal = 'HOLD';
                    confidence = 0;
                    reasons.push('Low volatility - skipping trade');
                }

                // Avoid trading if RSI is neutral
                if (lastRSI > 45 && lastRSI < 55) {
                    signal = 'HOLD';
                    confidence = 0;
                    reasons.push('RSI neutral zone');
                }
            }

            return {
                signal,
                confidence,
                reasons,
                indicators: {
                    rsi: lastRSI,
                    emaFast: lastEMAFast,
                    emaSlow: lastEMASlow,
                    macd: lastMACD.MACD,
                    macdSignal: lastMACD.signal,
                    bbUpper: lastBB.upper,
                    bbLower: lastBB.lower,
                    atr: lastATR,
                    volumeRatio
                }
            };

        } catch (error) {
            logger.error('Strategy analysis error:', error);
            return { signal: 'HOLD', confidence: 0, reason: 'Analysis error' };
        }
    }
}

module.exports = RSI_EMA_MACD_Strategy;