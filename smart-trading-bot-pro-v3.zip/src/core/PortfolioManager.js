const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/Logger');

class PortfolioManager {
    constructor(initialBalance = 10000) {
        this.initialBalance = initialBalance;
        this.balance = initialBalance;
        this.positions = [];
        this.closedTrades = [];
        this.dailyStats = {
            date: new Date().toDateString(),
            trades: 0,
            wins: 0,
            losses: 0,
            profit: 0,
            loss: 0
        };
        this.totalStats = {
            totalTrades: 0,
            wins: 0,
            losses: 0,
            totalProfit: 0,
            totalLoss: 0,
            maxDrawdown: 0,
            peakBalance: initialBalance
        };
    }

    openPosition(symbol, direction, entryPrice, quantity, stopLoss, takeProfit, strategy, indicators = {}) {
        const position = {
            id: uuidv4(),
            symbol,
            direction,
            entryPrice,
            quantity,
            stopLoss,
            takeProfit,
            strategy,
            indicators,
            isOpen: true,
            openTime: Date.now(),
            openTimeFormatted: new Date().toISOString(),
            highestPrice: entryPrice,
            lowestPrice: entryPrice,
            currentPrice: entryPrice,
            unrealizedPnL: 0,
            unrealizedPnLPercent: 0,
            fees: entryPrice * quantity * 0.001, // 0.1% fee
            status: 'OPEN'
        };

        this.positions.push(position);
        this.balance -= (entryPrice * quantity) + position.fees;

        logger.info(`Position opened: ${direction} ${quantity} ${symbol} @ ${entryPrice}`);
        return position;
    }

    closePosition(positionId, closePrice, reason = 'manual') {
        const index = this.positions.findIndex(p => p.id === positionId);
        if (index === -1) return null;

        const position = this.positions[index];
        position.isOpen = false;
        position.closePrice = closePrice;
        position.closeTime = Date.now();
        position.closeTimeFormatted = new Date().toISOString();
        position.closeReason = reason;

        // Calculate PnL
        const grossPnL = position.direction === 'BUY' 
            ? (closePrice - position.entryPrice) * position.quantity
            : (position.entryPrice - closePrice) * position.quantity;

        const closeFees = closePrice * position.quantity * 0.001;
        position.realizedPnL = grossPnL - position.fees - closeFees;
        position.realizedPnLPercent = (position.realizedPnL / (position.entryPrice * position.quantity)) * 100;

        // Update balance
        this.balance += (closePrice * position.quantity) - closeFees;

        // Move to closed trades
        this.closedTrades.unshift(position);
        this.positions.splice(index, 1);

        // Update stats
        this.updateStats(position);

        logger.info(`Position closed: ${position.symbol} @ ${closePrice}, PnL: ${position.realizedPnL.toFixed(2)} (${reason})`);
        return position;
    }

    updatePositionPrice(positionId, currentPrice) {
        const position = this.positions.find(p => p.id === positionId);
        if (!position || !position.isOpen) return null;

        position.currentPrice = currentPrice;

        // Update highest/lowest prices
        if (currentPrice > position.highestPrice) position.highestPrice = currentPrice;
        if (currentPrice < position.lowestPrice) position.lowestPrice = currentPrice;

        // Calculate unrealized PnL
        const grossPnL = position.direction === 'BUY'
            ? (currentPrice - position.entryPrice) * position.quantity
            : (position.entryPrice - currentPrice) * position.quantity;

        position.unrealizedPnL = grossPnL - position.fees;
        position.unrealizedPnLPercent = (position.unrealizedPnL / (position.entryPrice * position.quantity)) * 100;

        // Check if stop loss or take profit hit
        if (position.direction === 'BUY') {
            if (currentPrice <= position.stopLoss) {
                return this.closePosition(positionId, position.stopLoss, 'stop_loss');
            }
            if (currentPrice >= position.takeProfit) {
                return this.closePosition(positionId, position.takeProfit, 'take_profit');
            }
        } else {
            if (currentPrice >= position.stopLoss) {
                return this.closePosition(positionId, position.stopLoss, 'stop_loss');
            }
            if (currentPrice <= position.takeProfit) {
                return this.closePosition(positionId, position.takeProfit, 'take_profit');
            }
        }

        return position;
    }

    updateAllPositions(prices) {
        const results = [];
        for (const position of [...this.positions]) {
            const price = prices[position.symbol];
            if (price) {
                const result = this.updatePositionPrice(position.id, price);
                if (result) results.push(result);
            }
        }
        return results;
    }

    closeAllPositions(prices, reason = 'manual') {
        const closed = [];
        for (const position of [...this.positions]) {
            const price = prices[position.symbol] || position.currentPrice;
            const result = this.closePosition(position.id, price, reason);
            if (result) closed.push(result);
        }
        return closed;
    }

    closeWinningPositions(prices) {
        const closed = [];
        for (const position of [...this.positions]) {
            if (position.unrealizedPnL > 0) {
                const price = prices[position.symbol] || position.currentPrice;
                const result = this.closePosition(position.id, price, 'winning_manual');
                if (result) closed.push(result);
            }
        }
        return closed;
    }

    updateStats(position) {
        this.totalStats.totalTrades++;
        this.dailyStats.trades++;

        if (position.realizedPnL > 0) {
            this.totalStats.wins++;
            this.totalStats.totalProfit += position.realizedPnL;
            this.dailyStats.wins++;
            this.dailyStats.profit += position.realizedPnL;
        } else {
            this.totalStats.losses++;
            this.totalStats.totalLoss += Math.abs(position.realizedPnL);
            this.dailyStats.losses++;
            this.dailyStats.loss += Math.abs(position.realizedPnL);
        }

        // Update peak and drawdown
        if (this.balance > this.totalStats.peakBalance) {
            this.totalStats.peakBalance = this.balance;
        }
        const drawdown = ((this.totalStats.peakBalance - this.balance) / this.totalStats.peakBalance) * 100;
        if (drawdown > this.totalStats.maxDrawdown) {
            this.totalStats.maxDrawdown = drawdown;
        }
    }

    getPortfolioSummary() {
        const totalUnrealized = this.positions.reduce((sum, p) => sum + p.unrealizedPnL, 0);
        const totalInvested = this.positions.reduce((sum, p) => sum + (p.entryPrice * p.quantity), 0);

        return {
            balance: this.balance,
            initialBalance: this.initialBalance,
            totalReturn: ((this.balance - this.initialBalance) / this.initialBalance) * 100,
            equity: this.balance + totalUnrealized + totalInvested,
            availableBalance: this.balance,
            totalUnrealizedPnL: totalUnrealized,
            openPositions: this.positions.length,
            totalPositions: this.closedTrades.length + this.positions.length,
            winRate: this.totalStats.totalTrades > 0 
                ? (this.totalStats.wins / this.totalStats.totalTrades) * 100 
                : 0,
            profitFactor: this.totalStats.totalLoss > 0 
                ? this.totalStats.totalProfit / this.totalStats.totalLoss 
                : 0,
            maxDrawdown: this.totalStats.maxDrawdown,
            sharpeRatio: this.calculateSharpe(),
            dailyStats: this.dailyStats,
            totalStats: this.totalStats
        };
    }

    calculateSharpe() {
        if (this.closedTrades.length < 10) return 0;

        const returns = this.closedTrades.map(t => t.realizedPnLPercent);
        const avg = returns.reduce((a, b) => a + b, 0) / returns.length;
        const variance = returns.reduce((sum, r) => sum + Math.pow(r - avg, 2), 0) / returns.length;
        const stdDev = Math.sqrt(variance);

        return stdDev > 0 ? (avg / stdDev) * Math.sqrt(252) : 0; // Annualized
    }

    getOpenPositions() {
        return this.positions.map(p => ({
            id: p.id,
            symbol: p.symbol,
            direction: p.direction,
            entryPrice: p.entryPrice,
            currentPrice: p.currentPrice,
            quantity: p.quantity,
            stopLoss: p.stopLoss,
            takeProfit: p.takeProfit,
            unrealizedPnL: p.unrealizedPnL,
            unrealizedPnLPercent: p.unrealizedPnLPercent,
            highestPrice: p.highestPrice,
            lowestPrice: p.lowestPrice,
            openTime: p.openTimeFormatted,
            duration: this.formatDuration(Date.now() - p.openTime),
            strategy: p.strategy,
            status: p.status
        }));
    }

    getClosedTrades(limit = 50) {
        return this.closedTrades.slice(0, limit).map(t => ({
            id: t.id,
            symbol: t.symbol,
            direction: t.direction,
            entryPrice: t.entryPrice,
            closePrice: t.closePrice,
            quantity: t.quantity,
            realizedPnL: t.realizedPnL,
            realizedPnLPercent: t.realizedPnLPercent,
            openTime: t.openTimeFormatted,
            closeTime: t.closeTimeFormatted,
            duration: this.formatDuration(t.closeTime - t.openTime),
            closeReason: t.closeReason,
            strategy: t.strategy
        }));
    }

    formatDuration(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days}d ${hours % 24}h`;
        if (hours > 0) return `${hours}h ${minutes % 60}m`;
        if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
        return `${seconds}s`;
    }

    reset() {
        this.balance = this.initialBalance;
        this.positions = [];
        this.closedTrades = [];
        this.dailyStats = {
            date: new Date().toDateString(),
            trades: 0, wins: 0, losses: 0, profit: 0, loss: 0
        };
        this.totalStats = {
            totalTrades: 0, wins: 0, losses: 0,
            totalProfit: 0, totalLoss: 0, maxDrawdown: 0, peakBalance: this.initialBalance
        };
    }
}

module.exports = PortfolioManager;
