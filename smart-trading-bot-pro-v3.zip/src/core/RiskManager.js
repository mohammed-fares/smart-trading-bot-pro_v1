const logger = require('../utils/Logger');
const config = require('../../config/default.json');

class RiskManager {
    constructor(marketType = 'spot', leverage = 1) {
        this.marketType = marketType;
        this.leverage = leverage;
        this.riskPerTrade = config.trading.riskPerTrade || 2;
        this.maxOpenTrades = config.trading.maxOpenTrades || 5;

        if (marketType === 'futures') {
            this.maxLeverage = config.trading.futures.maxLeverage || 125;
            this.marginType = config.trading.futures.marginType || 'isolated';
        }
    }

    setMarketType(type) {
        this.marketType = type;
        logger.info(`RiskManager market type set to: ${type}`);
    }

    setLeverage(leverage) {
        if (this.marketType === 'futures') {
            const maxLev = config.trading.futures.maxLeverage || 125;
            this.leverage = Math.min(leverage, maxLev);
            logger.info(`Leverage set to: ${this.leverage}x`);
        } else {
            this.leverage = 1;
        }
    }

    calculatePositionSize(balance, riskPercent, entryPrice, stopLossPrice, symbol) {
        try {
            const riskAmount = balance * (riskPercent / 100);
            const stopDistance = Math.abs(entryPrice - stopLossPrice);

            if (stopDistance === 0) {
                logger.warn('Stop loss distance is zero, using default position size');
                return (balance * 0.02) / entryPrice;
            }

            let positionSize = riskAmount / stopDistance;

            // For futures, adjust for leverage
            if (this.marketType === 'futures') {
                positionSize = positionSize * this.leverage;
            }

            const maxPosition = (balance * 0.1) / entryPrice; // Max 10% of balance

            return Math.min(positionSize, maxPosition);
        } catch (error) {
            logger.error('Error calculating position size:', error);
            return (balance * 0.01) / entryPrice;
        }
    }

    calculateStopLoss(entryPrice, direction, atr, multiplier = 2) {
        const stopDistance = atr * multiplier;

        if (direction === 'LONG') {
            return entryPrice - stopDistance;
        } else {
            return entryPrice + stopDistance;
        }
    }

    calculateTakeProfit(entryPrice, direction, stopLossPrice, riskRewardRatio = 2) {
        const stopDistance = Math.abs(entryPrice - stopLossPrice);
        const targetDistance = stopDistance * riskRewardRatio;

        if (direction === 'LONG') {
            return entryPrice + targetDistance;
        } else {
            return entryPrice - targetDistance;
        }
    }

    calculateTrailingStop(currentPrice, highestPrice, lowestPrice, direction, trailingPercent = 2) {
        if (direction === 'LONG') {
            const newStop = highestPrice * (1 - trailingPercent / 100);
            const minStop = currentPrice * 0.95;
            return Math.max(newStop, minStop);
        } else {
            const newStop = lowestPrice * (1 + trailingPercent / 100);
            const maxStop = currentPrice * 1.05;
            return Math.min(newStop, maxStop);
        }
    }

    calculateLiquidationPrice(entryPrice, direction, leverage, marginType = 'isolated') {
        if (this.marketType !== 'futures') return null;

        // Simplified liquidation calculation
        // Real calculation would include maintenance margin
        const maintenanceMargin = 0.005; // 0.5%
        const liquidationThreshold = 1 / leverage - maintenanceMargin;

        if (direction === 'LONG') {
            return entryPrice * (1 - liquidationThreshold);
        } else {
            return entryPrice * (1 + liquidationThreshold);
        }
    }

    calculateMargin(entryPrice, quantity, leverage) {
        if (this.marketType !== 'futures') return entryPrice * quantity;
        return (entryPrice * quantity) / leverage;
    }

    calculateFundingFee(positionSize, fundingRate) {
        if (this.marketType !== 'futures') return 0;
        return positionSize * fundingRate;
    }

    canOpenTrade(openTradesCount, currentBalance, usedMargin = 0) {
        if (openTradesCount >= this.maxOpenTrades) {
            return { allowed: false, reason: 'Maximum open trades reached' };
        }

        if (currentBalance <= 0) {
            return { allowed: false, reason: 'Insufficient balance' };
        }

        if (this.marketType === 'futures') {
            const availableMargin = currentBalance - usedMargin;
            if (availableMargin <= 0) {
                return { allowed: false, reason: 'Insufficient margin' };
            }
        }

        return { allowed: true, reason: null };
    }

    validateTradeParams(symbol, direction, entryPrice, stopLoss, takeProfit) {
        const errors = [];

        if (!symbol || symbol.length < 3) {
            errors.push('Invalid symbol');
        }

        if (!['LONG', 'SHORT'].includes(direction)) {
            errors.push('Direction must be LONG or SHORT');
        }

        if (entryPrice <= 0) {
            errors.push('Invalid entry price');
        }

        if (stopLoss <= 0) {
            errors.push('Invalid stop loss');
        }

        if (takeProfit <= 0) {
            errors.push('Invalid take profit');
        }

        if (direction === 'LONG' && stopLoss >= entryPrice) {
            errors.push('Long stop loss must be below entry price');
        }

        if (direction === 'LONG' && takeProfit <= entryPrice) {
            errors.push('Long take profit must be above entry price');
        }

        if (direction === 'SHORT' && stopLoss <= entryPrice) {
            errors.push('Short stop loss must be above entry price');
        }

        if (direction === 'SHORT' && takeProfit >= entryPrice) {
            errors.push('Short take profit must be below entry price');
        }

        // Futures-specific validation
        if (this.marketType === 'futures') {
            if (this.leverage < 1 || this.leverage > this.maxLeverage) {
                errors.push(`Leverage must be between 1 and ${this.maxLeverage}`);
            }
        }

        return {
            valid: errors.length === 0,
            errors
        };
    }

    calculateDrawdown(equityHistory) {
        if (equityHistory.length < 2) return 0;

        let peak = equityHistory[0];
        let maxDrawdown = 0;

        for (const equity of equityHistory) {
            if (equity > peak) {
                peak = equity;
            }
            const drawdown = (peak - equity) / peak;
            if (drawdown > maxDrawdown) {
                maxDrawdown = drawdown;
            }
        }

        return maxDrawdown * 100;
    }

    calculateKellyCriterion(winRate, avgWin, avgLoss) {
        if (avgLoss === 0) return 0;
        const kelly = (winRate - ((1 - winRate) / (avgWin / avgLoss)));
        return Math.max(0, Math.min(kelly, 0.25));
    }

    getRiskInfo() {
        return {
            marketType: this.marketType,
            leverage: this.leverage,
            riskPerTrade: this.riskPerTrade,
            maxOpenTrades: this.maxOpenTrades,
            marginType: this.marketType === 'futures' ? this.marginType : null,
            maxLeverage: this.marketType === 'futures' ? this.maxLeverage : null
        };
    }
}

module.exports = RiskManager;