const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/Logger');
const db = require('../utils/Database');
const RiskManager = require('./RiskManager');
const BinanceAdapter = require('../exchanges/BinanceAdapter');
const config = require('../../config/default.json');

class TradingEngine {
    constructor() {
        this.marketType = config.trading.marketType || 'spot';
        this.riskManager = new RiskManager(this.marketType);
        this.exchange = new BinanceAdapter(this.marketType);
        this.isRunning = false;
        this.paperBalance = config.trading.paperBalance || 10000;
        this.initialCapital = this.paperBalance;
        this.equity = this.paperBalance;
        this.openTrades = new Map();
        this.tradeHistory = [];
        this.stats = {
            totalTrades: 0,
            winningTrades: 0,
            losingTrades: 0,
            totalPnL: 0,
            maxDrawdown: 0,
            equityHistory: [this.paperBalance],
            fundingFees: 0
        };
        this.strategy = null;
        this.tradingPair = config.trading.defaultPair || 'BTCUSDT';
        this.timeframe = config.trading.defaultTimeframe || '1h';
        this.leverage = config.trading.futures.leverage || 1;
        this.onTradeUpdate = null;
        this.onStatsUpdate = null;
        this.onActivityLog = null;
        this.startTime = null;
        this.monitorInterval = null;
        this.priceHistory = new Map();
        this.usedMargin = 0;
        this.fundingRate = 0;
    }

    setMarketType(type) {
        if (!['spot', 'futures'].includes(type)) {
            throw new Error('Market type must be "spot" or "futures"');
        }

        const oldType = this.marketType;
        this.marketType = type;
        this.exchange.setMarketType(type);
        this.riskManager.setMarketType(type);

        if (type === 'futures') {
            this.riskManager.setLeverage(this.leverage);
        } else {
            this.leverage = 1;
            this.riskManager.setLeverage(1);
        }

        logger.info(`Market type changed: ${oldType} → ${type}`);

        if (this.onActivityLog) {
            this.onActivityLog({
                type: 'CONFIG',
                action: 'SET_MARKET_TYPE',
                timestamp: Date.now(),
                details: `Market type changed to ${type.toUpperCase()}`
            });
        }
    }

    setLeverage(leverage) {
        if (this.marketType !== 'futures') {
            throw new Error('Leverage only available for futures trading');
        }

        const availableLeverages = config.trading.futures.availableLeverages || [1, 2, 3, 5, 10, 20, 50, 75, 100, 125];
        if (!availableLeverages.includes(parseInt(leverage))) {
            throw new Error(`Invalid leverage. Available: ${availableLeverages.join(', ')}`);
        }

        this.leverage = parseInt(leverage);
        this.riskManager.setLeverage(this.leverage);

        logger.info(`Leverage set to: ${this.leverage}x`);

        if (this.onActivityLog) {
            this.onActivityLog({
                type: 'CONFIG',
                action: 'SET_LEVERAGE',
                timestamp: Date.now(),
                details: `Leverage set to ${this.leverage}x`
            });
        }
    }

    setStrategy(strategy) {
        this.strategy = strategy;
        logger.info(`Strategy set to: ${strategy.name}`);
    }

    setTradingPair(pair) {
        this.tradingPair = pair;
        logger.info(`Trading pair set to: ${pair}`);
    }

    setTimeframe(tf) {
        this.timeframe = tf;
        logger.info(`Timeframe set to: ${tf}`);
    }

    setCapital(newCapital) {
        const minCapital = config.trading.minCapital || 100;
        const maxCapital = config.trading.maxCapital || 1000000;

        if (newCapital < minCapital) {
            throw new Error(`Minimum capital is $${minCapital}`);
        }
        if (newCapital > maxCapital) {
            throw new Error(`Maximum capital is $${maxCapital}`);
        }

        const oldCapital = this.paperBalance;
        this.paperBalance = newCapital;
        this.initialCapital = newCapital;
        this.equity = newCapital;

        // Log capital change
        db.logCapitalChange(oldCapital, newCapital, 'Manual capital update');
        db.logActivity('CAPITAL', 'CAPITAL_CHANGE', 
            `Capital changed from $${oldCapital.toFixed(2)} to $${newCapital.toFixed(2)}`, 
            'SUCCESS');

        logger.info(`Capital updated: $${oldCapital.toFixed(2)} → $${newCapital.toFixed(2)}`);

        if (this.onStatsUpdate) {
            this.updateStats();
        }

        if (this.onActivityLog) {
            this.onActivityLog({
                type: 'CAPITAL',
                action: 'CAPITAL_CHANGE',
                timestamp: Date.now(),
                details: `Capital changed from $${oldCapital.toFixed(2)} to $${newCapital.toFixed(2)}`
            });
        }

        return { oldCapital, newCapital };
    }

    getCapital() {
        return {
            current: this.paperBalance,
            initial: this.initialCapital,
            equity: this.equity,
            available: this.paperBalance - this.getUsedMargin(),
            usedMargin: this.getUsedMargin(),
            freeMargin: this.paperBalance - this.getUsedMargin()
        };
    }

    getUsedMargin() {
        let used = 0;
        for (const trade of this.openTrades.values()) {
            if (this.marketType === 'futures') {
                used += (trade.entryPrice * trade.quantity) / this.leverage;
            } else {
                used += trade.entryPrice * trade.quantity;
            }
        }
        return used;
    }

    setCallbacks(onTradeUpdate, onStatsUpdate, onActivityLog) {
        this.onTradeUpdate = onTradeUpdate;
        this.onStatsUpdate = onStatsUpdate;
        this.onActivityLog = onActivityLog;
    }

    async start() {
        if (this.isRunning) {
            logger.warn('Trading engine is already running');
            return;
        }

        this.isRunning = true;
        this.startTime = Date.now();

        // Log activity
        await db.logActivity('ENGINE', 'START_TRADING', 
            `Started ${this.marketType.toUpperCase()} trading. Pair: ${this.tradingPair}, Timeframe: ${this.timeframe}, Capital: $${this.paperBalance.toFixed(2)}, Leverage: ${this.leverage}x`, 
            'SUCCESS');

        logger.info('🚀 Trading engine started');
        logger.info(`📊 Capital: $${this.paperBalance.toFixed(2)} | Pair: ${this.tradingPair} | Timeframe: ${this.timeframe} | Market: ${this.marketType.toUpperCase()} | Leverage: ${this.leverage}x`);

        try {
            // Load historical data
            const klines = await this.exchange.getKlines(this.tradingPair, this.timeframe, 200);
            this.priceHistory.set(this.tradingPair, klines);

            // Get funding rate for futures
            if (this.marketType === 'futures') {
                const fundingInfo = await this.exchange.getFundingRate(this.tradingPair);
                if (fundingInfo) {
                    this.fundingRate = fundingInfo.fundingRate;
                    logger.info(`Funding rate: ${(this.fundingRate * 100).toFixed(4)}%`);
                }
            }

            // Subscribe to real-time data
            this.exchange.subscribeToKlines(this.tradingPair, this.timeframe, (candle) => {
                this.handleNewCandle(candle);
            });

            this.exchange.subscribeToPrice(this.tradingPair, (priceData) => {
                this.handlePriceUpdate(priceData);
            });

            // Start monitoring open trades
            this.monitorInterval = setInterval(() => {
                this.monitorOpenTrades();
            }, 1000);

            // Log first activity
            if (this.onActivityLog) {
                this.onActivityLog({
                    type: 'ENGINE',
                    action: 'START_TRADING',
                    timestamp: this.startTime,
                    details: `Trading started. Market: ${this.marketType.toUpperCase()}, Capital: $${this.paperBalance.toFixed(2)}, Leverage: ${this.leverage}x`
                });
            }

        } catch (error) {
            logger.error('Error starting trading engine:', error);
            await db.logActivity('ENGINE', 'START_TRADING', error.message, 'ERROR');
            this.stop();
        }
    }

    stop() {
        if (!this.isRunning) return;

        this.isRunning = false;

        if (this.monitorInterval) {
            clearInterval(this.monitorInterval);
            this.monitorInterval = null;
        }

        this.exchange.unsubscribe(this.tradingPair, this.timeframe);

        const duration = this.startTime ? Date.now() - this.startTime : 0;

        db.logActivity('ENGINE', 'STOP_TRADING', 
            `Stopped ${this.marketType.toUpperCase()} trading. Duration: ${this.formatDuration(duration)}`, 
            'SUCCESS');

        logger.info('🛑 Trading engine stopped');
        logger.info(`⏱️  Trading duration: ${this.formatDuration(duration)}`);

        if (this.onActivityLog) {
            this.onActivityLog({
                type: 'ENGINE',
                action: 'STOP_TRADING',
                timestamp: Date.now(),
                details: `Trading stopped after ${this.formatDuration(duration)}`
            });
        }
    }

    formatDuration(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days}d ${hours % 24}h ${minutes % 60}m`;
        if (hours > 0) return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
        if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
        return `${seconds}s`;
    }

    getUptime() {
        if (!this.startTime || !this.isRunning) return 0;
        return Date.now() - this.startTime;
    }

    getStatus() {
        return {
            isRunning: this.isRunning,
            startTime: this.startTime,
            uptime: this.getUptime(),
            uptimeFormatted: this.isRunning ? this.formatDuration(this.getUptime()) : 'Stopped',
            pair: this.tradingPair,
            timeframe: this.timeframe,
            strategy: this.strategy ? this.strategy.name : null,
            marketType: this.marketType,
            leverage: this.leverage,
            capital: this.getCapital(),
            openTradesCount: this.openTrades.size,
            fundingRate: this.fundingRate
        };
    }

    async handleNewCandle(candle) {
        if (!candle.isClosed) return;

        const history = this.priceHistory.get(this.tradingPair) || [];
        history.push({
            timestamp: candle.timestamp,
            open: candle.open,
            high: candle.high,
            low: candle.low,
            close: candle.close,
            volume: candle.volume
        });

        if (history.length > 200) {
            history.shift();
        }

        this.priceHistory.set(this.tradingPair, history);

        if (this.strategy && history.length >= 50) {
            await this.analyzeAndTrade(history);
        }
    }

    handlePriceUpdate(priceData) {
        this.updateUnrealizedPnL(priceData.price);
    }

    async analyzeAndTrade(candles) {
        try {
            const signal = this.strategy.analyze(candles);

            if (!signal || signal.signal === 'HOLD') return;

            const currentPrice = candles[candles.length - 1].close;
            const direction = signal.signal === 'BUY' ? 'LONG' : 'SHORT';

            // For spot, only allow LONG (buy)
            if (this.marketType === 'spot' && direction === 'SHORT') {
                return;
            }

            const canTrade = this.riskManager.canOpenTrade(
                this.openTrades.size, 
                this.paperBalance,
                this.getUsedMargin()
            );

            if (!canTrade.allowed) {
                logger.info(`Cannot open trade: ${canTrade.reason}`);
                return;
            }

            for (const trade of this.openTrades.values()) {
                if (trade.symbol === this.tradingPair && trade.direction === direction) {
                    return;
                }
            }

            const atr = this.calculateATR(candles, 14);
            const stopLoss = this.riskManager.calculateStopLoss(
                currentPrice, direction, atr, 2
            );
            const takeProfit = this.riskManager.calculateTakeProfit(
                currentPrice, direction, stopLoss, 2
            );
            const quantity = this.riskManager.calculatePositionSize(
                this.paperBalance, 
                this.riskManager.riskPerTrade, 
                currentPrice, 
                stopLoss,
                this.tradingPair
            );

            const validation = this.riskManager.validateTradeParams(
                this.tradingPair, direction, currentPrice, stopLoss, takeProfit
            );

            if (!validation.valid) {
                logger.warn('Trade validation failed:', validation.errors);
                return;
            }

            await this.openTrade({
                symbol: this.tradingPair,
                direction,
                entryPrice: currentPrice,
                quantity,
                stopLoss,
                takeProfit,
                strategy: this.strategy.name,
                confidence: signal.confidence || 0.5,
                marketType: this.marketType,
                leverage: this.leverage
            });

        } catch (error) {
            logger.error('Error in analyze and trade:', error);
        }
    }

    async openTrade(tradeParams) {
        const tradeId = uuidv4();

        // Calculate margin and fees
        const positionValue = tradeParams.entryPrice * tradeParams.quantity;
        const margin = this.marketType === 'futures' 
            ? positionValue / this.leverage 
            : positionValue;
        const fees = positionValue * 0.0004; // 0.04% taker fee

        const trade = {
            id: tradeId,
            ...tradeParams,
            status: 'OPEN',
            openTime: Date.now(),
            pnl: 0,
            pnlPercent: 0,
            highestPrice: tradeParams.entryPrice,
            lowestPrice: tradeParams.entryPrice,
            currentPrice: tradeParams.entryPrice,
            margin: margin,
            fees: fees,
            fundingFees: 0
        };

        // For futures, calculate liquidation price
        if (this.marketType === 'futures') {
            trade.liquidationPrice = this.riskManager.calculateLiquidationPrice(
                trade.entryPrice, trade.direction, this.leverage
            );
        }

        this.openTrades.set(tradeId, trade);
        this.paperBalance -= fees;

        await db.run(`
            INSERT INTO trades (id, symbol, direction, entryPrice, quantity, stopLoss, takeProfit, 
                              status, strategy, confidence, openTime, fees, margin, marketType, leverage, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            trade.id, trade.symbol, trade.direction, trade.entryPrice, trade.quantity,
            trade.stopLoss, trade.takeProfit, trade.status, trade.strategy, 
            trade.confidence, trade.openTime, trade.fees, trade.margin, trade.marketType, 
            trade.leverage, JSON.stringify({ liquidationPrice: trade.liquidationPrice })
        ]);

        await db.logActivity('TRADE', 'OPEN_TRADE',
            `${trade.marketType.toUpperCase()} ${trade.direction} ${trade.symbol} @ $${trade.entryPrice.toFixed(2)} Qty: ${trade.quantity.toFixed(6)} Margin: $${trade.margin.toFixed(2)} Leverage: ${trade.leverage}x`,
            'SUCCESS');

        logger.info(`📈 Trade opened: [${trade.marketType.toUpperCase()}] ${trade.direction} ${trade.symbol} @ ${trade.entryPrice} (Qty: ${trade.quantity.toFixed(6)}, Margin: $${trade.margin.toFixed(2)}, Leverage: ${trade.leverage}x)`);

        if (this.onTradeUpdate) {
            this.onTradeUpdate('OPEN', trade);
        }

        if (this.onActivityLog) {
            this.onActivityLog({
                type: 'TRADE',
                action: 'OPEN_TRADE',
                timestamp: trade.openTime,
                details: `Opened ${trade.marketType.toUpperCase()} ${trade.direction} ${trade.symbol} @ $${trade.entryPrice.toFixed(2)} (Leverage: ${trade.leverage}x)`
            });
        }

        return trade;
    }

    updateUnrealizedPnL(currentPrice) {
        for (const trade of this.openTrades.values()) {
            trade.currentPrice = currentPrice;

            if (currentPrice > trade.highestPrice) trade.highestPrice = currentPrice;
            if (currentPrice < trade.lowestPrice) trade.lowestPrice = currentPrice;

            if (trade.direction === 'LONG') {
                trade.pnl = (currentPrice - trade.entryPrice) * trade.quantity - trade.fees;
            } else {
                trade.pnl = (trade.entryPrice - currentPrice) * trade.quantity - trade.fees;
            }

            // For futures, include leverage in PnL calculation
            if (trade.marketType === 'futures') {
                trade.pnl = trade.pnl * trade.leverage;
            }

            trade.pnlPercent = (trade.pnl / (trade.entryPrice * trade.quantity)) * 100;

            // Check for liquidation
            if (trade.marketType === 'futures' && trade.liquidationPrice) {
                if (trade.direction === 'LONG' && currentPrice <= trade.liquidationPrice) {
                    trade.liquidated = true;
                } else if (trade.direction === 'SHORT' && currentPrice >= trade.liquidationPrice) {
                    trade.liquidated = true;
                }
            }
        }

        const openPnL = Array.from(this.openTrades.values()).reduce((sum, t) => sum + t.pnl, 0);
        this.equity = this.paperBalance + openPnL;
    }

    monitorOpenTrades() {
        for (const [tradeId, trade] of this.openTrades.entries()) {
            const currentPrice = trade.currentPrice;

            if (!currentPrice) continue;

            // Check for liquidation first
            if (trade.liquidated) {
                this.closeTrade(tradeId, currentPrice, 'LIQUIDATION');
                continue;
            }

            let shouldClose = false;
            let closeReason = '';

            if (trade.direction === 'LONG') {
                if (currentPrice <= trade.stopLoss) {
                    shouldClose = true;
                    closeReason = 'STOP_LOSS';
                } else if (currentPrice >= trade.takeProfit) {
                    shouldClose = true;
                    closeReason = 'TAKE_PROFIT';
                }
            } else {
                if (currentPrice >= trade.stopLoss) {
                    shouldClose = true;
                    closeReason = 'STOP_LOSS';
                } else if (currentPrice <= trade.takeProfit) {
                    shouldClose = true;
                    closeReason = 'TAKE_PROFIT';
                }
            }

            // Update trailing stop
            if (trade.direction === 'LONG' && currentPrice > trade.entryPrice) {
                const newStop = this.riskManager.calculateTrailingStop(
                    currentPrice, trade.highestPrice, trade.lowestPrice, 'LONG', 2
                );
                if (newStop > trade.stopLoss) {
                    trade.stopLoss = newStop;
                }
            } else if (trade.direction === 'SHORT' && currentPrice < trade.entryPrice) {
                const newStop = this.riskManager.calculateTrailingStop(
                    currentPrice, trade.highestPrice, trade.lowestPrice, 'SHORT', 2
                );
                if (newStop < trade.stopLoss) {
                    trade.stopLoss = newStop;
                }
            }

            if (shouldClose) {
                this.closeTrade(tradeId, currentPrice, closeReason);
            }
        }

        this.updateStats();
    }

    async closeTrade(tradeId, exitPrice, reason) {
        const trade = this.openTrades.get(tradeId);
        if (!trade) return;

        trade.status = 'CLOSED';
        trade.exitPrice = exitPrice;
        trade.closeTime = Date.now();
        trade.closeReason = reason;

        // Calculate exit fees
        const exitFees = (trade.quantity * exitPrice) * 0.0004;

        if (trade.direction === 'LONG') {
            trade.pnl = (exitPrice - trade.entryPrice) * trade.quantity - trade.fees - exitFees;
        } else {
            trade.pnl = (trade.entryPrice - exitPrice) * trade.quantity - trade.fees - exitFees;
        }

        // For futures, apply leverage to PnL
        if (trade.marketType === 'futures') {
            trade.pnl = trade.pnl * trade.leverage;
        }

        trade.pnlPercent = (trade.pnl / (trade.entryPrice * trade.quantity)) * 100;

        // Return margin for futures
        if (trade.marketType === 'futures') {
            this.paperBalance += trade.margin;
        }

        this.paperBalance += trade.pnl;

        this.stats.totalTrades++;
        if (trade.pnl > 0) {
            this.stats.winningTrades++;
        } else {
            this.stats.losingTrades++;
        }
        this.stats.totalPnL += trade.pnl;
        this.stats.equityHistory.push(this.paperBalance);
        this.stats.maxDrawdown = this.riskManager.calculateDrawdown(this.stats.equityHistory);

        await db.run(`
            UPDATE trades 
            SET status = ?, exitPrice = ?, pnl = ?, pnlPercent = ?, closeTime = ?, closeReason = ?
            WHERE id = ?
        `, [
            trade.status, trade.exitPrice, trade.pnl, trade.pnlPercent, 
            trade.closeTime, trade.closeReason, trade.id
        ]);

        await db.logActivity('TRADE', 'CLOSE_TRADE',
            `${trade.marketType.toUpperCase()} ${trade.direction} ${trade.symbol} closed @ $${exitPrice.toFixed(2)} | PnL: $${trade.pnl.toFixed(2)} | Reason: ${reason}`,
            trade.pnl >= 0 ? 'SUCCESS' : 'WARNING');

        this.openTrades.delete(tradeId);
        this.tradeHistory.push(trade);

        logger.info(`📉 Trade closed: [${trade.marketType.toUpperCase()}] ${trade.direction} ${trade.symbol} @ ${exitPrice} | PnL: ${trade.pnl.toFixed(2)} (${trade.pnlPercent.toFixed(2)}%) | Reason: ${reason}`);

        if (this.onTradeUpdate) {
            this.onTradeUpdate('CLOSED', trade);
        }

        if (this.onActivityLog) {
            this.onActivityLog({
                type: 'TRADE',
                action: 'CLOSE_TRADE',
                timestamp: trade.closeTime,
                details: `Closed ${trade.marketType.toUpperCase()} ${trade.direction} ${trade.symbol} @ $${exitPrice.toFixed(2)} | PnL: $${trade.pnl.toFixed(2)}`
            });
        }

        return trade;
    }

    async closeAllTrades(reason = 'MANUAL') {
        const trades = Array.from(this.openTrades.values());
        for (const trade of trades) {
            await this.closeTrade(trade.id, trade.currentPrice, reason);
        }

        await db.logActivity('TRADE', 'CLOSE_ALL_TRADES',
            `Closed ${trades.length} trades manually`,
            'SUCCESS');

        logger.info(`All trades closed manually. Total closed: ${trades.length}`);
    }

    async closeWinningTrades() {
        const winningTrades = Array.from(this.openTrades.values()).filter(t => t.pnl > 0);
        for (const trade of winningTrades) {
            await this.closeTrade(trade.id, trade.currentPrice, 'MANUAL_PROFIT');
        }

        await db.logActivity('TRADE', 'CLOSE_WINNING_TRADES',
            `Closed ${winningTrades.length} winning trades`,
            'SUCCESS');

        logger.info(`Winning trades closed. Total closed: ${winningTrades.length}`);
    }

    async closeLosingTrades() {
        const losingTrades = Array.from(this.openTrades.values()).filter(t => t.pnl < 0);
        for (const trade of losingTrades) {
            await this.closeTrade(trade.id, trade.currentPrice, 'MANUAL_CUT_LOSS');
        }

        await db.logActivity('TRADE', 'CLOSE_LOSING_TRADES',
            `Closed ${losingTrades.length} losing trades`,
            'SUCCESS');

        logger.info(`Losing trades closed. Total closed: ${losingTrades.length}`);
    }

    updateStats() {
        const openPnL = Array.from(this.openTrades.values()).reduce((sum, t) => sum + t.pnl, 0);
        this.equity = this.paperBalance + openPnL;

        const stats = {
            ...this.stats,
            paperBalance: this.paperBalance,
            equity: this.equity,
            openPnL: openPnL,
            openTradesCount: this.openTrades.size,
            usedMargin: this.getUsedMargin(),
            freeMargin: this.paperBalance - this.getUsedMargin(),
            winRate: this.stats.totalTrades > 0 
                ? (this.stats.winningTrades / this.stats.totalTrades * 100).toFixed(2) 
                : 0,
            avgPnL: this.stats.totalTrades > 0 
                ? (this.stats.totalPnL / this.stats.totalTrades).toFixed(2) 
                : 0,
            marketType: this.marketType,
            leverage: this.leverage
        };

        if (this.onStatsUpdate) {
            this.onStatsUpdate(stats);
        }
    }

    calculateATR(candles, period = 14) {
        if (candles.length < period + 1) return 0;

        let trSum = 0;
        for (let i = candles.length - period; i < candles.length; i++) {
            const high = candles[i].high;
            const low = candles[i].low;
            const prevClose = candles[i - 1].close;

            const tr1 = high - low;
            const tr2 = Math.abs(high - prevClose);
            const tr3 = Math.abs(low - prevClose);

            trSum += Math.max(tr1, tr2, tr3);
        }

        return trSum / period;
    }

    getOpenTrades() {
        return Array.from(this.openTrades.values());
    }

    getTradeHistory() {
        return this.tradeHistory;
    }

    getStats() {
        return {
            ...this.stats,
            paperBalance: this.paperBalance,
            equity: this.equity,
            openTradesCount: this.openTrades.size,
            usedMargin: this.getUsedMargin(),
            freeMargin: this.paperBalance - this.getUsedMargin(),
            winRate: this.stats.totalTrades > 0 
                ? (this.stats.winningTrades / this.stats.totalTrades * 100).toFixed(2) 
                : 0,
            avgPnL: this.stats.totalTrades > 0 
                ? (this.stats.totalPnL / this.stats.totalTrades).toFixed(2) 
                : 0,
            marketType: this.marketType,
            leverage: this.leverage,
            initialCapital: this.initialCapital
        };
    }

    reset() {
        this.stop();
        this.paperBalance = this.initialCapital;
        this.equity = this.paperBalance;
        this.openTrades.clear();
        this.tradeHistory = [];
        this.stats = {
            totalTrades: 0,
            winningTrades: 0,
            losingTrades: 0,
            totalPnL: 0,
            maxDrawdown: 0,
            equityHistory: [this.paperBalance],
            fundingFees: 0
        };
        this.priceHistory.clear();
        this.startTime = null;
        this.usedMargin = 0;

        db.logActivity('ENGINE', 'RESET', 'Trading engine reset', 'SUCCESS');
        logger.info('Trading engine reset');
    }
}

module.exports = TradingEngine;