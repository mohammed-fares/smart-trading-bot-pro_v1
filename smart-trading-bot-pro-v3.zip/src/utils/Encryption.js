const crypto = require('crypto');
const config = require('../../config/default.json');

const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32;
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const SALT_LENGTH = 64;

class Encryption {
    constructor() {
        this.masterKey = process.env.ENCRYPTION_KEY || config.security.encryptionKey;
        if (this.masterKey.length < 32) {
            throw new Error('Encryption key must be at least 32 characters');
        }
    }

    deriveKey(password, salt) {
        return crypto.pbkdf2Sync(password, salt, 100000, KEY_LENGTH, 'sha512');
    }

    encrypt(text) {
        try {
            const salt = crypto.randomBytes(SALT_LENGTH);
            const key = this.deriveKey(this.masterKey, salt);
            const iv = crypto.randomBytes(IV_LENGTH);

            const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
            let encrypted = cipher.update(text, 'utf8', 'hex');
            encrypted += cipher.final('hex');

            const authTag = cipher.getAuthTag();

            return {
                salt: salt.toString('hex'),
                iv: iv.toString('hex'),
                encrypted: encrypted,
                authTag: authTag.toString('hex')
            };
        } catch (error) {
            throw new Error(`Encryption failed: ${error.message}`);
        }
    }

    decrypt(encryptedData) {
        try {
            const salt = Buffer.from(encryptedData.salt, 'hex');
            const iv = Buffer.from(encryptedData.iv, 'hex');
            const authTag = Buffer.from(encryptedData.authTag, 'hex');

            const key = this.deriveKey(this.masterKey, salt);

            const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
            decipher.setAuthTag(authTag);

            let decrypted = decipher.update(encryptedData.encrypted, 'hex', 'utf8');
            decrypted += decipher.final('utf8');

            return decrypted;
        } catch (error) {
            throw new Error(`Decryption failed: ${error.message}`);
        }
    }

    hash(text) {
        return crypto.createHash('sha256').update(text).digest('hex');
    }

    generateSecureToken() {
        return crypto.randomBytes(32).toString('hex');
    }
}

module.exports = new Encryption();