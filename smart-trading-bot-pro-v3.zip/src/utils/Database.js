const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const logger = require('./Logger');

class Database {
    constructor() {
        this.dbPath = process.env.DB_PATH || './data/trading.db';
        this.ensureDirectory();
        this.db = new sqlite3.Database(this.dbPath);
        this.initTables();
    }

    ensureDirectory() {
        const dir = path.dirname(this.dbPath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
    }

    initTables() {
        const tables = `
            CREATE TABLE IF NOT EXISTS trades (
                id TEXT PRIMARY KEY,
                symbol TEXT NOT NULL,
                direction TEXT NOT NULL,
                entryPrice REAL NOT NULL,
                exitPrice REAL,
                quantity REAL NOT NULL,
                stopLoss REAL,
                takeProfit REAL,
                pnl REAL DEFAULT 0,
                pnlPercent REAL DEFAULT 0,
                status TEXT DEFAULT 'OPEN',
                strategy TEXT,
                confidence REAL,
                openTime INTEGER NOT NULL,
                closeTime INTEGER,
                closeReason TEXT,
                fees REAL DEFAULT 0,
                metadata TEXT
            );

            CREATE TABLE IF NOT EXISTS balance_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                balance REAL NOT NULL,
                equity REAL NOT NULL,
                openPnl REAL DEFAULT 0,
                totalTrades INTEGER DEFAULT 0,
                winningTrades INTEGER DEFAULT 0,
                losingTrades INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS market_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                open REAL,
                high REAL,
                low REAL,
                close REAL,
                volume REAL,
                UNIQUE(symbol, timestamp)
            );

            CREATE TABLE IF NOT EXISTS signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                strategy TEXT NOT NULL,
                signal TEXT NOT NULL,
                confidence REAL,
                price REAL,
                executed BOOLEAN DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                type TEXT NOT NULL,
                action TEXT NOT NULL,
                details TEXT,
                status TEXT,
                user TEXT DEFAULT 'system'
            );

            CREATE TABLE IF NOT EXISTS capital_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                oldCapital REAL,
                newCapital REAL,
                reason TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
            CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
            CREATE INDEX IF NOT EXISTS idx_market_data_symbol_time ON market_data(symbol, timestamp);
            CREATE INDEX IF NOT EXISTS idx_activity_log_timestamp ON activity_log(timestamp);
            CREATE INDEX IF NOT EXISTS idx_activity_log_type ON activity_log(type);
        `;

        this.db.exec(tables, (err) => {
            if (err) {
                logger.error('Database initialization error:', err);
            } else {
                logger.info('Database tables initialized successfully');
            }
        });
    }

    // Activity Log Methods
    async logActivity(type, action, details = '', status = 'SUCCESS', user = 'system') {
        try {
            await this.run(
                'INSERT INTO activity_log (timestamp, type, action, details, status, user) VALUES (?, ?, ?, ?, ?, ?)',
                [Date.now(), type, action, details, status, user]
            );
        } catch (error) {
            logger.error('Error logging activity:', error);
        }
    }

    async getActivityLog(limit = 100, type = null) {
        try {
            let query = 'SELECT * FROM activity_log';
            let params = [];

            if (type) {
                query += ' WHERE type = ?';
                params.push(type);
            }

            query += ' ORDER BY timestamp DESC LIMIT ?';
            params.push(limit);

            return await this.all(query, params);
        } catch (error) {
            logger.error('Error getting activity log:', error);
            return [];
        }
    }

    async getLastActivity(type, action) {
        try {
            return await this.get(
                'SELECT * FROM activity_log WHERE type = ? AND action = ? ORDER BY timestamp DESC LIMIT 1',
                [type, action]
            );
        } catch (error) {
            logger.error('Error getting last activity:', error);
            return null;
        }
    }

    // Capital History Methods
    async logCapitalChange(oldCapital, newCapital, reason = '') {
        try {
            await this.run(
                'INSERT INTO capital_history (timestamp, oldCapital, newCapital, reason) VALUES (?, ?, ?, ?)',
                [Date.now(), oldCapital, newCapital, reason]
            );
        } catch (error) {
            logger.error('Error logging capital change:', error);
        }
    }

    async getCapitalHistory(limit = 50) {
        try {
            return await this.all(
                'SELECT * FROM capital_history ORDER BY timestamp DESC LIMIT ?',
                [limit]
            );
        } catch (error) {
            logger.error('Error getting capital history:', error);
            return [];
        }
    }

    run(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(sql, params, function(err) {
                if (err) reject(err);
                else resolve({ id: this.lastID, changes: this.changes });
            });
        });
    }

    get(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(sql, params, (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    all(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(sql, params, (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }

    close() {
        return new Promise((resolve, reject) => {
            this.db.close((err) => {
                if (err) reject(err);
                else resolve();
            });
        });
    }
}

module.exports = new Database();