const express = require('express');
const WebSocket = require('ws');
const http = require('http');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const logger = require('./utils/Logger');
const db = require('./utils/Database');
const TradingEngine = require('./core/TradingEngine');
const StrategyFactory = require('./strategies/StrategyFactory');
const config = require('../config/default.json');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Security middleware - allow inline scripts for our dashboard
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://cdnjs.cloudflare.com"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
            fontSrc: ["'self'", "https://cdnjs.cloudflare.com"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'", "ws:", "wss:"]
        }
    }
}));

app.use(cors());
app.use(express.json());

const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: { error: 'Too many requests, please try again later' }
});
app.use('/api/', limiter);

// Static files
app.use(express.static(path.join(__dirname, '../web')));

// Global state
const tradingEngine = new TradingEngine();
let connectedClients = new Set();
let broadcastInterval = null;

// ============ WEBSOCKET ============
wss.on('connection', (ws) => {
    logger.info('New WebSocket client connected');
    connectedClients.add(ws);

    // Send initial state
    sendToClient(ws, {
        type: 'INIT',
        data: {
            isRunning: tradingEngine.isRunning,
            stats: tradingEngine.getStats(),
            openTrades: tradingEngine.getOpenTrades(),
            strategies: StrategyFactory.getAvailableStrategies(),
            currentStrategy: tradingEngine.strategy ? tradingEngine.strategy.name : null,
            tradingPair: tradingEngine.tradingPair,
            timeframe: tradingEngine.timeframe,
            marketType: tradingEngine.marketType,
            leverage: tradingEngine.leverage,
            capital: tradingEngine.getCapital(),
            status: tradingEngine.getStatus()
        }
    });

    ws.on('message', async (message) => {
        try {
            const command = JSON.parse(message);
            await handleCommand(ws, command);
        } catch (error) {
            logger.error('WebSocket message error:', error);
            sendToClient(ws, { type: 'ERROR', message: error.message });
        }
    });

    ws.on('close', () => {
        connectedClients.delete(ws);
        logger.info('WebSocket client disconnected');
    });

    ws.on('error', (error) => {
        logger.error('WebSocket error:', error);
        connectedClients.delete(ws);
    });
});

function sendToClient(ws, data) {
    if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(data));
    }
}

function broadcast(data) {
    const message = JSON.stringify(data);
    connectedClients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(message);
        }
    });
}

// ============ REAL-TIME BROADCAST ============
function startBroadcasting() {
    if (broadcastInterval) return;

    broadcastInterval = setInterval(() => {
        const stats = tradingEngine.getStats();
        const openTrades = tradingEngine.getOpenTrades();
        const status = tradingEngine.getStatus();

        broadcast({
            type: 'UPDATE',
            timestamp: Date.now(),
            data: {
                stats,
                openTrades,
                status,
                isRunning: tradingEngine.isRunning
            }
        });
    }, 1000);
}

function stopBroadcasting() {
    if (broadcastInterval) {
        clearInterval(broadcastInterval);
        broadcastInterval = null;
    }
}

// ============ COMMAND HANDLER ============
async function handleCommand(ws, command) {
    const { action, payload } = command;

    try {
        switch (action) {
            case 'START_TRADING':
                if (!tradingEngine.isRunning) {
                    await tradingEngine.start();
                    startBroadcasting();
                    broadcast({ type: 'STATUS', isRunning: true });
                    logger.info('Trading started via WebSocket');
                }
                break;

            case 'STOP_TRADING':
                tradingEngine.stop();
                stopBroadcasting();
                broadcast({ type: 'STATUS', isRunning: false });
                logger.info('Trading stopped via WebSocket');
                break;

            case 'CLOSE_ALL_TRADES':
                await tradingEngine.closeAllTrades('MANUAL_ALL');
                broadcast({
                    type: 'NOTIFICATION',
                    message: 'All trades closed manually',
                    trades: tradingEngine.getOpenTrades()
                });
                break;

            case 'CLOSE_WINNING_TRADES':
                await tradingEngine.closeWinningTrades();
                broadcast({
                    type: 'NOTIFICATION',
                    message: 'Winning trades closed',
                    trades: tradingEngine.getOpenTrades()
                });
                break;

            case 'CLOSE_LOSING_TRADES':
                await tradingEngine.closeLosingTrades();
                broadcast({
                    type: 'NOTIFICATION',
                    message: 'Losing trades closed',
                    trades: tradingEngine.getOpenTrades()
                });
                break;

            case 'SET_STRATEGY':
                const strategy = StrategyFactory.create(payload.strategy);
                tradingEngine.setStrategy(strategy);
                broadcast({
                    type: 'CONFIG_UPDATE',
                    currentStrategy: strategy.name
                });
                break;

            case 'SET_PAIR':
                tradingEngine.setTradingPair(payload.pair);
                broadcast({
                    type: 'CONFIG_UPDATE',
                    tradingPair: payload.pair
                });
                break;

            case 'SET_TIMEFRAME':
                tradingEngine.setTimeframe(payload.timeframe);
                broadcast({
                    type: 'CONFIG_UPDATE',
                    timeframe: payload.timeframe
                });
                break;

            case 'SET_MARKET_TYPE':
                tradingEngine.setMarketType(payload.marketType);
                broadcast({
                    type: 'CONFIG_UPDATE',
                    marketType: payload.marketType
                });
                break;

            case 'SET_LEVERAGE':
                tradingEngine.setLeverage(payload.leverage);
                broadcast({
                    type: 'CONFIG_UPDATE',
                    leverage: payload.leverage
                });
                break;

            case 'SET_CAPITAL':
                const capitalResult = tradingEngine.setCapital(payload.capital);
                broadcast({
                    type: 'CAPITAL_UPDATE',
                    capital: tradingEngine.getCapital()
                });
                break;

            case 'RESET':
                tradingEngine.reset();
                broadcast({
                    type: 'NOTIFICATION',
                    message: 'Trading engine reset',
                    stats: tradingEngine.getStats(),
                    openTrades: []
                });
                break;

            case 'GET_HISTORY':
                const history = await db.all(
                    'SELECT * FROM trades ORDER BY openTime DESC LIMIT ?',
                    [payload.limit || 100]
                );
                sendToClient(ws, { type: 'TRADE_HISTORY', data: history });
                break;

            case 'GET_STATS':
                sendToClient(ws, {
                    type: 'STATS',
                    data: tradingEngine.getStats()
                });
                break;

            case 'GET_ACTIVITY_LOG':
                const logType = payload.type || null;
                const logLimit = payload.limit || 100;
                const activityLog = await db.getActivityLog(logLimit, logType);
                sendToClient(ws, { type: 'ACTIVITY_LOG', data: activityLog });
                break;

            case 'GET_CAPITAL_HISTORY':
                const capitalHistory = await db.getCapitalHistory(payload.limit || 50);
                sendToClient(ws, { type: 'CAPITAL_HISTORY', data: capitalHistory });
                break;

            default:
                sendToClient(ws, { type: 'ERROR', message: 'Unknown command' });
        }
    } catch (error) {
        logger.error('Command error:', error);
        sendToClient(ws, { type: 'ERROR', message: error.message });
    }
}

// ============ REST API ============

// Get current status
app.get('/api/status', (req, res) => {
    res.json({
        isRunning: tradingEngine.isRunning,
        stats: tradingEngine.getStats(),
        openTrades: tradingEngine.getOpenTrades(),
        currentStrategy: tradingEngine.strategy ? tradingEngine.strategy.name : null,
        tradingPair: tradingEngine.tradingPair,
        timeframe: tradingEngine.timeframe,
        marketType: tradingEngine.marketType,
        leverage: tradingEngine.leverage,
        capital: tradingEngine.getCapital(),
        status: tradingEngine.getStatus()
    });
});

// Get available strategies
app.get('/api/strategies', (req, res) => {
    res.json(StrategyFactory.getAvailableStrategies());
});

// Get available market types
app.get('/api/market-types', (req, res) => {
    res.json({
        available: config.trading.availableMarketTypes || ['spot', 'futures'],
        current: tradingEngine.marketType,
        futures: {
            availableLeverages: config.trading.futures.availableLeverages || [1, 2, 3, 5, 10, 20, 50, 75, 100, 125],
            maxLeverage: config.trading.futures.maxLeverage || 125,
            marginType: config.trading.futures.marginType || 'isolated'
        }
    });
});

// Get trade history
app.get('/api/trades/history', async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 100;
        const trades = await db.all(
            'SELECT * FROM trades ORDER BY openTime DESC LIMIT ?',
            [limit]
        );
        res.json(trades);
    } catch (error) {
        logger.error('Error fetching trade history:', error);
        res.status(500).json({ error: 'Failed to fetch trade history' });
    }
});

// Get open trades
app.get('/api/trades/open', (req, res) => {
    res.json(tradingEngine.getOpenTrades());
});

// Get balance history
app.get('/api/balance/history', async (req, res) => {
    try {
        const history = await db.all(
            'SELECT * FROM balance_history ORDER BY timestamp DESC LIMIT ?',
            [parseInt(req.query.limit) || 100]
        );
        res.json(history);
    } catch (error) {
        logger.error('Error fetching balance history:', error);
        res.status(500).json({ error: 'Failed to fetch balance history' });
    }
});

// Get capital history
app.get('/api/capital/history', async (req, res) => {
    try {
        const history = await db.getCapitalHistory(parseInt(req.query.limit) || 50);
        res.json(history);
    } catch (error) {
        logger.error('Error fetching capital history:', error);
        res.status(500).json({ error: 'Failed to fetch capital history' });
    }
});

// Get activity log
app.get('/api/activity-log', async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 100;
        const type = req.query.type || null;
        const log = await db.getActivityLog(limit, type);
        res.json(log);
    } catch (error) {
        logger.error('Error fetching activity log:', error);
        res.status(500).json({ error: 'Failed to fetch activity log' });
    }
});

// Get available trading pairs from Binance
app.get('/api/pairs', async (req, res) => {
    try {
        const exchange = new (require('./exchanges/BinanceAdapter'))(tradingEngine.marketType);
        const symbols = await exchange.getExchangeInfo();
        const usdtPairs = symbols
            .filter(s => s.symbol.endsWith('USDT') && s.quoteAsset === 'USDT')
            .map(s => ({
                symbol: s.symbol,
                baseAsset: s.baseAsset,
                quoteAsset: s.quoteAsset,
                minQty: s.filters.find(f => f.filterType === 'LOT_SIZE')?.minQty,
                tickSize: s.filters.find(f => f.filterType === 'PRICE_FILTER')?.tickSize
            }));
        res.json(usdtPairs);
    } catch (error) {
        logger.error('Error fetching pairs:', error);
        res.status(500).json({ error: 'Failed to fetch trading pairs' });
    }
});

// Start trading
app.post('/api/trading/start', async (req, res) => {
    try {
        if (tradingEngine.isRunning) {
            return res.json({ success: false, message: 'Trading already running' });
        }

        if (req.body.strategy) {
            const strategy = StrategyFactory.create(req.body.strategy);
            tradingEngine.setStrategy(strategy);
        }

        if (req.body.pair) tradingEngine.setTradingPair(req.body.pair);
        if (req.body.timeframe) tradingEngine.setTimeframe(req.body.timeframe);
        if (req.body.marketType) tradingEngine.setMarketType(req.body.marketType);
        if (req.body.leverage) tradingEngine.setLeverage(req.body.leverage);

        await tradingEngine.start();
        startBroadcasting();

        res.json({ success: true, message: 'Trading started' });
    } catch (error) {
        logger.error('Error starting trading:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Stop trading
app.post('/api/trading/stop', (req, res) => {
    tradingEngine.stop();
    stopBroadcasting();
    res.json({ success: true, message: 'Trading stopped' });
});

// Close all trades
app.post('/api/trades/close-all', async (req, res) => {
    try {
        await tradingEngine.closeAllTrades('MANUAL_API');
        res.json({ success: true, message: 'All trades closed' });
    } catch (error) {
        logger.error('Error closing all trades:', error);
        res.status(500).json({ error: error.message });
    }
});

// Close winning trades
app.post('/api/trades/close-winning', async (req, res) => {
    try {
        await tradingEngine.closeWinningTrades();
        res.json({ success: true, message: 'Winning trades closed' });
    } catch (error) {
        logger.error('Error closing winning trades:', error);
        res.status(500).json({ error: error.message });
    }
});

// Close losing trades
app.post('/api/trades/close-losing', async (req, res) => {
    try {
        await tradingEngine.closeLosingTrades();
        res.json({ success: true, message: 'Losing trades closed' });
    } catch (error) {
        logger.error('Error closing losing trades:', error);
        res.status(500).json({ error: error.message });
    }
});

// Set capital
app.post('/api/capital', async (req, res) => {
    try {
        const { capital } = req.body;
        if (!capital || isNaN(capital) || capital <= 0) {
            return res.status(400).json({ error: 'Invalid capital amount' });
        }

        const result = tradingEngine.setCapital(parseFloat(capital));
        res.json({ success: true, capital: tradingEngine.getCapital() });
    } catch (error) {
        logger.error('Error setting capital:', error);
        res.status(500).json({ error: error.message });
    }
});

// Set market type
app.post('/api/market-type', async (req, res) => {
    try {
        const { marketType } = req.body;
        if (!['spot', 'futures'].includes(marketType)) {
            return res.status(400).json({ error: 'Invalid market type. Must be "spot" or "futures"' });
        }

        tradingEngine.setMarketType(marketType);
        res.json({ success: true, marketType: tradingEngine.marketType });
    } catch (error) {
        logger.error('Error setting market type:', error);
        res.status(500).json({ error: error.message });
    }
});

// Set leverage
app.post('/api/leverage', async (req, res) => {
    try {
        const { leverage } = req.body;
        tradingEngine.setLeverage(parseInt(leverage));
        res.json({ success: true, leverage: tradingEngine.leverage });
    } catch (error) {
        logger.error('Error setting leverage:', error);
        res.status(500).json({ error: error.message });
    }
});

// Reset engine
app.post('/api/trading/reset', (req, res) => {
    tradingEngine.reset();
    res.json({ success: true, message: 'Trading engine reset' });
});

// Update settings
app.post('/api/settings', async (req, res) => {
    try {
        const { key, value } = req.body;
        await db.run(
            'INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
            [key, JSON.stringify(value), Date.now()]
        );
        res.json({ success: true });
    } catch (error) {
        logger.error('Error saving settings:', error);
        res.status(500).json({ error: error.message });
    }
});

// Get settings
app.get('/api/settings/:key', async (req, res) => {
    try {
        const row = await db.get('SELECT value FROM settings WHERE key = ?', [req.params.key]);
        res.json(row ? JSON.parse(row.value) : null);
    } catch (error) {
        logger.error('Error fetching settings:', error);
        res.status(500).json({ error: error.message });
    }
});

// Error handling
app.use((err, req, res, next) => {
    logger.error('Express error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

// ============ START SERVER ============
const PORT = process.env.PORT || config.server.port || 3000;

server.listen(PORT, () => {
    logger.info(`🚀 Smart Trading Bot Pro v2.0 running on port ${PORT}`);
    logger.info(`📊 Dashboard: http://localhost:${PORT}`);
    logger.info(`📡 WebSocket: ws://localhost:${PORT}`);
    logger.info(`📈 Market Types: Spot + Futures`);
    logger.info(`💰 Capital Control: Enabled`);
    logger.info(`📋 Activity Logging: Enabled`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    logger.info('SIGTERM received, shutting down gracefully');
    tradingEngine.stop();
    stopBroadcasting();
    server.close(() => {
        db.close().then(() => {
            logger.info('Server closed');
            process.exit(0);
        });
    });
});

process.on('SIGINT', () => {
    logger.info('SIGINT received, shutting down gracefully');
    tradingEngine.stop();
    stopBroadcasting();
    server.close(() => {
        db.close().then(() => {
            logger.info('Server closed');
            process.exit(0);
        });
    });
});