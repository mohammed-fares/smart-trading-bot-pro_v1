@echo off
echo Starting Smart Trading Bot Pro v2.0...
echo.

IF NOT EXIST node_modules (
    echo Installing dependencies...
    npm install
)

IF NOT EXIST .env (
    echo Creating .env file...
    copy .env.example .env
    echo Please edit .env file with your settings!
)

IF NOT EXIST logs mkdir logs
IF NOT EXIST data mkdir data

echo Starting server...
echo Dashboard: http://localhost:3000
echo WebSocket: ws://localhost:3000
echo.

npm start
