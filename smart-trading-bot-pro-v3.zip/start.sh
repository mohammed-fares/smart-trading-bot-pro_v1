#!/bin/bash

echo "🚀 Starting Smart Trading Bot Pro v2.0..."
echo ""

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚙️  Creating .env file..."
    cp .env.example .env
    echo "⚠️  Please edit .env file with your settings!"
fi

# Create logs directory
mkdir -p logs
mkdir -p data

echo "✅ Starting server..."
echo "📊 Dashboard: http://localhost:3000"
echo "📡 WebSocket: ws://localhost:3000"
echo ""

npm start
