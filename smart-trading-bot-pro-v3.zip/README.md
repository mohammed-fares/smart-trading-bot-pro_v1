# Smart Trading Bot Pro v2.0

## Advanced AI-Powered Trading Bot with Real-time Binance Data Simulation

### Features
- **Real-time Data**: Live WebSocket connection to Binance for real market data
- **Paper Trading**: Full simulation with virtual balance - no real money risk
- **Multiple Strategies**: RSI+EMA+MACD, Bollinger Band Breakout
- **Risk Management**: ATR-based stop loss, take profit, trailing stops, position sizing
- **Advanced Dashboard**: Real-time updates, trade history, statistics
- **Security**: AES-256-GCM encryption, rate limiting, secure API handling
- **Full Trade Control**: Start/Stop trading, close all/winning/losing trades

### Installation

```bash
# 1. Clone and enter directory
cd smart-trading-bot-pro-v2

# 2. Install dependencies
npm install

# 3. Create .env file
cp .env.example .env

# 4. Edit .env with your settings
# (Optional: Add Binance API keys for higher rate limits)

# 5. Start the server
npm start

# 6. Open dashboard
http://localhost:3000
```

### Configuration
Edit `config/default.json` or use environment variables:
- `PORT`: Server port (default: 3000)
- `BINANCE_API_KEY`: Binance API key (optional)
- `BINANCE_SECRET_KEY`: Binance secret key (optional)
- `ENCRYPTION_KEY`: 32-character encryption key
- `JWT_SECRET`: JWT secret for authentication

### Trading Strategies

#### 1. RSI + EMA + MACD
- Multi-indicator confirmation system
- RSI oversold/overbought detection
- EMA golden/death cross
- MACD signal crossover
- Volume confirmation
- Bollinger Band support

#### 2. Bollinger Band Breakout
- Bollinger Squeeze detection
- Band breakout with volume
- Trend following with EMA
- RSI momentum confirmation

### Risk Management
- Position sizing based on risk percentage
- ATR-based stop loss (2x ATR)
- Risk-Reward ratio 1:2
- Trailing stop loss
- Maximum drawdown tracking
- Kelly Criterion calculation

### API Endpoints
- `GET /api/status` - Current status
- `GET /api/trades/open` - Open trades
- `GET /api/trades/history` - Trade history
- `GET /api/strategies` - Available strategies
- `POST /api/trading/start` - Start trading
- `POST /api/trading/stop` - Stop trading
- `POST /api/trades/close-all` - Close all trades
- `POST /api/trades/close-winning` - Close winning trades
- `POST /api/trades/close-losing` - Close losing trades

### WebSocket Commands
- `START_TRADING` - Start trading engine
- `STOP_TRADING` - Stop trading engine
- `CLOSE_ALL_TRADES` - Close all open trades
- `CLOSE_WINNING_TRADES` - Close profitable trades
- `CLOSE_LOSING_TRADES` - Close losing trades
- `SET_STRATEGY` - Change trading strategy
- `SET_PAIR` - Change trading pair
- `SET_TIMEFRAME` - Change timeframe
- `RESET` - Reset engine
- `GET_HISTORY` - Get trade history
- `GET_STATS` - Get statistics

### Dashboard Features
- Real-time statistics updates (every second)
- Live open trades with PnL
- Complete closed trade history
- Start/Stop trading controls
- Close all/winning/losing trades buttons
- Strategy, pair, and timeframe selection
- Connection status indicator
- Notification system

### Database Schema
- `trades` - All trades (open and closed)
- `balance_history` - Balance/equity history
- `market_data` - Historical market data
- `signals` - Trading signals log
- `settings` - Bot configuration

### License
MIT
