import numpy as np
from typing import Tuple, Optional

def ema(data: np.ndarray, period: int) -> np.ndarray:
    if len(data) < period:
        return data
    alpha = 2.0 / (period + 1.0)
    result = np.zeros_like(data, dtype=float)
    result[0] = data[0]
    for i in range(1, len(data)):
        result[i] = alpha * data[i] + (1 - alpha) * result[i - 1]
    return result

def rsi(data: np.ndarray, period: int = 14) -> float:
    if len(data) < period + 1:
        return 50.0
    deltas = np.diff(data)
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    avg_gain = np.mean(gains[-period:])
    avg_loss = np.mean(losses[-period:])
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))

def macd(data: np.ndarray, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[float, float, float]:
    ema_fast = ema(data, fast)
    ema_slow = ema(data, slow)
    macd_line = ema_fast - ema_slow
    signal_line = ema(macd_line, signal)
    histogram = macd_line - signal_line
    return float(macd_line[-1]), float(signal_line[-1]), float(histogram[-1])

def bollinger_bands(data: np.ndarray, period: int = 20, std_dev: float = 2.0) -> Tuple[float, float, float]:
    if len(data) < period:
        return float(data[-1]), float(data[-1]), float(data[-1])
    middle = float(np.mean(data[-period:]))
    std = float(np.std(data[-period:]))
    upper = middle + std_dev * std
    lower = middle - std_dev * std
    return upper, middle, lower

def volume_spike(volume: np.ndarray, period: int = 20) -> Tuple[bool, float]:
    if len(volume) < period:
        return False, 1.0
    avg_volume = float(np.mean(volume[-period:]))
    current_volume = float(volume[-1])
    ratio = current_volume / avg_volume if avg_volume > 0 else 1.0
    return ratio > 2.0, ratio

def atr(data_high: np.ndarray, data_low: np.ndarray, data_close: np.ndarray, period: int = 14) -> float:
    if len(data_close) < 2:
        return 0.0
    tr1 = data_high[1:] - data_low[1:]
    tr2 = np.abs(data_high[1:] - data_close[:-1])
    tr3 = np.abs(data_low[1:] - data_close[:-1])
    tr = np.maximum(np.maximum(tr1, tr2), tr3)
    if len(tr) < period:
        return float(np.mean(tr))
    return float(np.mean(tr[-period:]))

def calculate_all_indicators(closes, highs=None, lows=None, volumes=None, config=None):
    from config import Config
    cfg = config or Config()

    indicators = {
        "price": float(closes[-1]),
        "ema_fast": float(ema(closes, cfg.EMA_FAST)[-1]),
        "ema_slow": float(ema(closes, cfg.EMA_SLOW)[-1]),
        "rsi": float(rsi(closes, cfg.RSI_PERIOD)),
    }

    if highs is not None and lows is not None:
        indicators["atr"] = float(atr(highs, lows, closes))
        bb_upper, bb_middle, bb_lower = bollinger_bands(closes)
        indicators["bb_upper"] = bb_upper
        indicators["bb_middle"] = bb_middle
        indicators["bb_lower"] = bb_lower
    else:
        indicators["atr"] = float(closes[-1] * 0.02)
        indicators["bb_upper"] = indicators["bb_middle"] = indicators["bb_lower"] = float(closes[-1])

    if volumes is not None and len(volumes) > 0:
        is_spike, ratio = volume_spike(volumes)
        indicators["volume_spike"] = is_spike
        indicators["volume_ratio"] = ratio
    else:
        indicators["volume_spike"] = False
        indicators["volume_ratio"] = 1.0

    indicators["trend"] = "BULLISH" if indicators["ema_fast"] > indicators["ema_slow"] else "BEARISH"

    macd_line, signal_line, histogram = macd(closes)
    indicators["macd"] = macd_line
    indicators["macd_signal"] = signal_line
    indicators["macd_histogram"] = histogram

    return indicators
