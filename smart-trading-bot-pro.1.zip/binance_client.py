import hmac
import hashlib
import time
import requests
from urllib.parse import urlencode
from config import Config

class BinanceClient:
    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.session = requests.Session()
        if self.config.BINANCE_API_KEY:
            self.session.headers.update({'X-MBX-APIKEY': self.config.BINANCE_API_KEY})

    def _generate_signature(self, query_string: str) -> str:
        return hmac.new(
            self.config.BINANCE_SECRET_KEY.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()

    def _get_timestamp(self) -> int:
        return int(time.time() * 1000)

    def _request(self, method: str, endpoint: str, base_url: str = None, params: dict = None, signed: bool = False):
        url = f"{base_url or self.config.BINANCE_BASE_URL}{endpoint}"
        params = params or {}
        params['timestamp'] = self._get_timestamp()

        if signed and self.config.BINANCE_SECRET_KEY:
            query = urlencode(params)
            params['signature'] = self._generate_signature(query)

        try:
            if method == 'GET':
                response = self.session.get(url, params=params, timeout=15)
            elif method == 'POST':
                response = self.session.post(url, params=params, timeout=15)
            elif method == 'DELETE':
                response = self.session.delete(url, params=params, timeout=15)
            else:
                raise ValueError(f"Unsupported method: {method}")

            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e), "status": "failed"}

    def get_klines(self, symbol: str, interval: str = "1h", limit: int = 100):
        return self._request('GET', '/api/v3/klines', params={
            'symbol': symbol, 'interval': interval, 'limit': limit
        })

    def get_ticker_price(self, symbol: str):
        return self._request('GET', '/api/v3/ticker/price', params={'symbol': symbol})

    def get_24h_stats(self, symbol: str):
        return self._request('GET', '/api/v3/ticker/24hr', params={'symbol': symbol})

    def get_order_book(self, symbol: str, limit: int = 100):
        return self._request('GET', '/api/v3/depth', params={'symbol': symbol, 'limit': limit})

    def get_account(self):
        return self._request('GET', '/api/v3/account', signed=True)

    def get_balance(self, asset: str) -> float:
        account = self.get_account()
        if 'balances' in account:
            for balance in account['balances']:
                if balance['asset'] == asset:
                    return float(balance['free'])
        return 0.0

    def place_order(self, symbol: str, side: str, order_type: str,
                   quantity: float = None, price: float = None,
                   stop_price: float = None, time_in_force: str = 'GTC'):
        params = {
            'symbol': symbol, 'side': side, 'type': order_type,
            'timeInForce': time_in_force
        }
        if quantity is not None:
            params['quantity'] = quantity
        if price is not None:
            params['price'] = price
        if stop_price is not None:
            params['stopPrice'] = stop_price
        return self._request('POST', '/api/v3/order', signed=True, params=params)

    def place_market_order(self, symbol: str, side: str, quantity: float):
        return self.place_order(symbol, side, 'MARKET', quantity=quantity)

    def place_limit_order(self, symbol: str, side: str, quantity: float, price: float):
        return self.place_order(symbol, side, 'LIMIT', quantity=quantity, price=price)

    def cancel_order(self, symbol: str, order_id: int):
        return self._request('DELETE', '/api/v3/order', signed=True, params={
            'symbol': symbol, 'orderId': order_id
        })

    def get_open_orders(self, symbol: str = None):
        params = {}
        if symbol:
            params['symbol'] = symbol
        return self._request('GET', '/api/v3/openOrders', signed=True, params=params)
