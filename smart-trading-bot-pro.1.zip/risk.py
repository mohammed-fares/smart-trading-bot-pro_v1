from typing import Dict
from config import Config

class RiskManager:
    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.open_positions = []
        self.daily_pnl = 0.0
        self.daily_trades = 0
        self.max_daily_loss = self.config.INITIAL_CAPITAL * 0.05
        self.total_trades = 0
        self.winning_trades = 0
        self.losing_trades = 0

    def can_trade(self):
        if len(self.open_positions) >= self.config.MAX_POSITIONS:
            return False, "Max positions reached"
        if self.daily_pnl <= -self.max_daily_loss:
            return False, "Daily loss limit reached"
        if self.daily_trades >= 20:
            return False, "Max daily trades reached"
        return True, "OK"

    def position_size(self, capital: float, entry: float, stop_loss: float, risk_pct: float = None):
        risk_pct = risk_pct or self.config.RISK_PER_TRADE
        risk_amount = capital * risk_pct / 100.0
        diff = abs(entry - stop_loss)
        if diff == 0:
            return 0.0
        return round(risk_amount / diff, 6)

    def calculate_risk_reward(self, entry: float, stop_loss: float, take_profit: float):
        risk = abs(entry - stop_loss)
        reward = abs(take_profit - entry)
        if risk == 0:
            return 0.0
        return round(reward / risk, 2)

    def validate_trade(self, signal_data: Dict, capital: float) -> Dict:
        can_trade, reason = self.can_trade()
        if not can_trade:
            return {"valid": False, "reason": reason}

        entry = signal_data.get("entry_price", 0)
        stop_loss = signal_data.get("stop_loss", 0)
        take_profit = signal_data.get("take_profit", 0)

        rr = self.calculate_risk_reward(entry, stop_loss, take_profit)
        if rr < self.config.MIN_RISK_REWARD:
            return {"valid": False, "reason": f"Risk/Reward too low ({rr}:1, min {self.config.MIN_RISK_REWARD}:1)"}

        size = self.position_size(capital, entry, stop_loss)
        max_position_value = capital * 0.10
        if size * entry > max_position_value:
            size = max_position_value / entry

        return {
            "valid": True,
            "size": round(size, 6),
            "entry": entry,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "risk_reward": rr,
            "risk_amount": capital * self.config.RISK_PER_TRADE / 100
        }

    def add_position(self, position: Dict):
        self.open_positions.append(position)
        self.daily_trades += 1
        self.total_trades += 1

    def close_position(self, position_id: str, pnl: float):
        self.open_positions = [p for p in self.open_positions if p.get("id") != position_id]
        self.daily_pnl += pnl
        if pnl > 0:
            self.winning_trades += 1
        else:
            self.losing_trades += 1

    def get_portfolio_risk(self) -> Dict:
        total_exposure = sum(p.get("size", 0) * p.get("entry", 0) for p in self.open_positions)
        win_rate = (self.winning_trades / self.total_trades * 100) if self.total_trades > 0 else 0

        return {
            "open_positions": len(self.open_positions),
            "total_exposure": round(total_exposure, 2),
            "daily_pnl": round(self.daily_pnl, 2),
            "daily_trades": self.daily_trades,
            "total_trades": self.total_trades,
            "winning_trades": self.winning_trades,
            "losing_trades": self.losing_trades,
            "win_rate": round(win_rate, 2),
            "max_positions": self.config.MAX_POSITIONS
        }

    def reset_daily_stats(self):
        self.daily_pnl = 0.0
        self.daily_trades = 0
