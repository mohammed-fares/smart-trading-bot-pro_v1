import os
from dataclasses import dataclass, field
from typing import List

@dataclass
class Config:
    """Configuration for Smart Trading Bot Pro"""

    # Binance API
    BINANCE_API_KEY: str = os.getenv("BINANCE_API_KEY", "")
    BINANCE_SECRET_KEY: str = os.getenv("BINANCE_SECRET_KEY", "")
    BINANCE_BASE_URL: str = "https://api.binance.com"
    BINANCE_FUTURES_URL: str = "https://fapi.binance.com"
    BINANCE_WS: str = "wss://stream.binance.com:9443/ws"
    BINANCE_FUTURES_WS: str = "wss://fstream.binance.com/ws"

    # Trading Settings
    INITIAL_CAPITAL: float = 10000.0
    RISK_PER_TRADE: float = 1.0
    MAX_POSITIONS: int = 5
    LEVERAGE: int = 1
    PAPER_TRADING: bool = True

    # Strategy
    EMA_FAST: int = 9
    EMA_SLOW: int = 21
    RSI_PERIOD: int = 14
    RSI_OVERSOLD: float = 30.0
    RSI_OVERBOUGHT: float = 70.0
    VOLUME_SPIKE_THRESHOLD: float = 2.0
    MIN_RISK_REWARD: float = 1.5

    # Telegram
    TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    TELEGRAM_CHAT_ID: str = os.getenv("TELEGRAM_CHAT_ID", "")

    # Symbols
    DEFAULT_SYMBOL: str = "BTCUSDT"
    TRADING_PAIRS: List[str] = field(default_factory=lambda: [
        "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "ADAUSDT"
    ])

    # Intervals
    CHECK_INTERVAL: int = 10
    WS_UPDATE_INTERVAL: int = 2
