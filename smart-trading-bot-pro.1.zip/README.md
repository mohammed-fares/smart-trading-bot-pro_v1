# Smart Trading Bot Pro v2.0

Professional Paper Trading Bot with Real Binance Market Data

## Features

- Real-time Binance WebSocket data
- Technical Indicators: RSI, EMA, MACD, Bollinger Bands, ATR
- Advanced Risk Management with position sizing
- Automatic trade execution and closure
- Paper Trading mode (simulated trades with real data)
- Backtesting with real historical data
- Telegram notifications
- FastAPI Dashboard with WebSocket
- Docker ready

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure environment (optional)
```bash
cp .env.example .env
# Edit .env with your API keys (optional for paper trading)
```

### 3. Run the bot
```bash
uvicorn main:app --reload --port 8000
```

### 4. Access dashboard
Open http://localhost:8000/dashboard

### 5. API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /` | Status and features |
| `GET /analyze?symbol=BTCUSDT` | Full technical analysis |
| `GET /backtest?symbol=BTCUSDT&days=30` | Run backtest |
| `GET /stats` | Current performance stats |
| `GET /trades?limit=50` | All trades history |
| `GET /dashboard` | HTML dashboard |
| `WS /ws` | Real-time updates |
| `WS /ws/price/BTCUSDT` | Live price feed |

## Paper Trading Mode

The bot runs in **Paper Trading** mode by default:
- Uses **real Binance market data** for price and indicators
- **Simulates trades** without real money
- Tracks PnL, win rate, drawdown as if real
- Logs all trades to `logs/trades.jsonl`

To switch to Live Trading, set `PAPER_TRADING = False` in `config.py` and provide valid API keys.

## Backtesting

Test the strategy on historical data:
```bash
curl "http://localhost:8000/backtest?symbol=BTCUSDT&days=30&interval=1h"
```

## Docker

```bash
docker-compose up -d
```

## Warning

This is for educational purposes. Trading carries significant risk. Always test thoroughly before using real funds.


## Kali Linux Setup

Kali uses an externally-managed Python environment. Use the provided setup script:

```bash
# 1. Navigate to project directory
cd smart-trading-bot-pro

# 2. Run setup (installs deps in virtualenv)
chmod +x setup.sh
./setup.sh

# 3. Start the bot
./run.sh
```

### Alternative: Manual Setup

```bash
# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate

# Install packages
pip install -r requirements.txt

# Run
uvicorn main:app --reload --port 8000
```

### Or use apt packages (not recommended, may be outdated):
```bash
sudo apt install python3-fastapi python3-uvicorn python3-websockets python3-numpy python3-aiohttp python3-requests
```
