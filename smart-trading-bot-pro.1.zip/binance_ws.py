import asyncio
import json
import websockets
from typing import Callable
from config import Config

class BinanceWebSocket:
    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.ws = None
        self.running = False
        self.price_callbacks = []
        self.trade_callbacks = []
        self.last_prices = {}
        self.last_volumes = {}

    async def connect(self, symbol: str):
        url = f"{self.config.BINANCE_WS}/{symbol.lower()}@trade"
        self.running = True

        while self.running:
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=10) as ws:
                    self.ws = ws
                    print(f"[WS] Connected to Binance: {symbol}")

                    while self.running:
                        try:
                            msg = await asyncio.wait_for(ws.recv(), timeout=30)
                            data = json.loads(msg)

                            price = float(data["p"])
                            quantity = float(data["q"])
                            self.last_prices[symbol] = price

                            if symbol not in self.last_volumes:
                                self.last_volumes[symbol] = []
                            self.last_volumes[symbol].append(quantity)
                            if len(self.last_volumes[symbol]) > 100:
                                self.last_volumes[symbol].pop(0)

                            trade_data = {
                                "symbol": symbol, "price": price,
                                "quantity": quantity, "time": data.get("T", 0),
                                "is_buyer_maker": data.get("m", False)
                            }

                            for callback in self.price_callbacks:
                                try:
                                    if asyncio.iscoroutinefunction(callback):
                                        await callback(symbol, price)
                                    else:
                                        callback(symbol, price)
                                except Exception as e:
                                    print(f"[WS] Callback error: {e}")

                            for callback in self.trade_callbacks:
                                try:
                                    if asyncio.iscoroutinefunction(callback):
                                        await callback(trade_data)
                                    else:
                                        callback(trade_data)
                                except Exception as e:
                                    print(f"[WS] Trade callback error: {e}")

                        except asyncio.TimeoutError:
                            continue

            except websockets.exceptions.ConnectionClosed:
                print(f"[WS] Disconnected from {symbol}, reconnecting in 5s...")
                await asyncio.sleep(5)
            except Exception as e:
                print(f"[WS] Error: {e}, reconnecting in 5s...")
                await asyncio.sleep(5)

    def add_price_callback(self, callback):
        self.price_callbacks.append(callback)

    def add_trade_callback(self, callback):
        self.trade_callbacks.append(callback)

    async def disconnect(self):
        self.running = False
        if self.ws:
            await self.ws.close()

    def get_last_price(self, symbol: str):
        return self.last_prices.get(symbol)

    def get_volume_history(self, symbol: str):
        return self.last_volumes.get(symbol, [])
