import aiohttp
from config import Config

class TelegramNotifier:
    def __init__(self, config=None):
        self.config = config or Config()
        self.enabled = bool(self.config.TELEGRAM_BOT_TOKEN and self.config.TELEGRAM_CHAT_ID)

    async def send_message(self, message):
        if not self.enabled:
            return
        url = "https://api.telegram.org/bot" + self.config.TELEGRAM_BOT_TOKEN + "/sendMessage"
        payload = {"chat_id": self.config.TELEGRAM_CHAT_ID, "text": message, "parse_mode": "HTML"}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=10) as response:
                    if response.status != 200:
                        print("[Telegram] Error: " + str(await response.text()))
        except Exception as e:
            print("[Telegram] Failed: " + str(e))

    async def send_trade_open(self, trade):
        emoji = "BUY" if trade["side"] == "BUY" else "SELL"
        lines = [
            emoji + " Paper Trade Opened",
            "",
            "Symbol: " + trade["symbol"],
            "Side: " + trade["side"],
            "Entry: $" + str(round(trade["entry"], 2)),
            "Stop Loss: $" + str(round(trade["stop_loss"], 2)),
            "Take Profit: $" + str(round(trade["take_profit"], 2)),
            "Size: " + str(trade["size"]),
            "R/R: " + str(trade.get("risk_reward", 0)) + ":1",
            "Confidence: " + str(trade.get("confidence", 0)) + "%"
        ]
        await self.send_message("\n".join(lines))

    async def send_trade_close(self, trade):
        pnl = trade.get("pnl", 0)
        emoji = "WIN" if pnl > 0 else "LOSS"
        lines = [
            emoji + " Paper Trade Closed",
            "",
            "Symbol: " + trade["symbol"],
            "Side: " + trade["side"],
            "Entry: $" + str(round(trade["entry"], 2)),
            "Exit: $" + str(round(trade.get("exit_price", 0), 2)),
            "Reason: " + trade.get("exit_reason", "Unknown"),
            "PnL: $" + str(round(pnl, 2)) + " (" + str(round(trade.get("pnl_pct", 0), 2)) + "%)"
        ]
        await self.send_message("\n".join(lines))
