from typing import Dict
from config import Config

class StrategyEngine:
    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.last_signal = "NEUTRAL"
        self.signal_history = []

    def decide(self, indicators: Dict) -> Dict:
        score = 0
        reasons = []
        price = indicators.get("price", 0)

        # RSI
        rsi_val = indicators.get("rsi", 50)
        if rsi_val < self.config.RSI_OVERSOLD:
            score += 2
            reasons.append(f"RSI oversold ({rsi_val:.1f})")
        elif rsi_val > self.config.RSI_OVERBOUGHT:
            score -= 2
            reasons.append(f"RSI overbought ({rsi_val:.1f})")
        elif rsi_val < 40:
            score += 1
            reasons.append(f"RSI low ({rsi_val:.1f})")
        elif rsi_val > 60:
            score -= 1
            reasons.append(f"RSI high ({rsi_val:.1f})")

        # EMA
        ema_fast = indicators.get("ema_fast", 0)
        ema_slow = indicators.get("ema_slow", 0)
        if ema_fast > ema_slow:
            score += 2
            reasons.append("EMA Fast > EMA Slow (Bullish)")
        else:
            score -= 2
            reasons.append("EMA Fast < EMA Slow (Bearish)")

        # MACD
        macd = indicators.get("macd", 0)
        macd_signal = indicators.get("macd_signal", 0)
        if macd > macd_signal:
            score += 1
            reasons.append("MACD above signal")
        else:
            score -= 1
            reasons.append("MACD below signal")

        # Volume
        if indicators.get("volume_spike", False):
            score += 1
            reasons.append(f"Volume spike ({indicators.get('volume_ratio', 1):.1f}x)")

        # Bollinger
        bb_lower = indicators.get("bb_lower", 0)
        bb_upper = indicators.get("bb_upper", 0)
        if price < bb_lower:
            score += 1
            reasons.append("Price below lower BB")
        elif price > bb_upper:
            score -= 1
            reasons.append("Price above upper BB")

        # Trend
        if indicators.get("trend") == "BULLISH" and score > 0:
            score += 1
            reasons.append("Bullish trend confirmed")
        elif indicators.get("trend") == "BEARISH" and score < 0:
            score -= 1
            reasons.append("Bearish trend confirmed")

        confidence = min(abs(score) * 15, 100)

        if score >= 5:
            signal = "STRONG_BUY"
        elif score >= 3:
            signal = "BUY"
        elif score <= -5:
            signal = "STRONG_SELL"
        elif score <= -3:
            signal = "SELL"
        else:
            signal = "NEUTRAL"

        atr_val = indicators.get("atr", price * 0.02)
        if "BUY" in signal:
            entry = price
            stop_loss = price - (2.0 * atr_val)
            take_profit = price + (3.0 * atr_val)
        elif "SELL" in signal:
            entry = price
            stop_loss = price + (2.0 * atr_val)
            take_profit = price - (3.0 * atr_val)
        else:
            entry = stop_loss = take_profit = price

        result = {
            "signal": signal,
            "confidence": round(confidence, 1),
            "score": score,
            "reasons": reasons,
            "entry_price": round(entry, 2),
            "stop_loss": round(stop_loss, 2),
            "take_profit": round(take_profit, 2),
            "atr": round(atr_val, 2),
            "rsi": round(rsi_val, 1),
            "ema_fast": round(ema_fast, 2),
            "ema_slow": round(ema_slow, 2)
        }

        self.last_signal = signal
        self.signal_history.append(result)
        if len(self.signal_history) > 100:
            self.signal_history.pop(0)

        return result

    def should_enter_trade(self, indicators: Dict) -> bool:
        result = self.decide(indicators)
        return result["signal"] in ["BUY", "STRONG_BUY"] and result["confidence"] >= 45

    def should_exit_trade(self, indicators: Dict, entry_price: float, side: str) -> bool:
        current_price = indicators.get("price", 0)
        result = self.decide(indicators)

        if side == "LONG":
            if result["signal"] in ["SELL", "STRONG_SELL"]:
                return True
            if current_price <= entry_price * 0.97:
                return True
        elif side == "SHORT":
            if result["signal"] in ["BUY", "STRONG_BUY"]:
                return True
            if current_price >= entry_price * 1.03:
                return True

        return False
