import numpy as np
from config import Config
from strategy import StrategyEngine
from risk import RiskManager
from indicators import calculate_all_indicators
from binance_client import BinanceClient

class BacktestEngine:
    def __init__(self, config=None):
        self.config = config or Config()
        self.strategy = StrategyEngine(self.config)
        self.risk = RiskManager(self.config)
        self.client = BinanceClient(self.config)
        self.trades = []
        self.equity_curve = []
        self.capital = self.config.INITIAL_CAPITAL
        self.peak = self.config.INITIAL_CAPITAL
        self.max_drawdown = 0.0

    def run(self, symbol="BTCUSDT", interval="1h", days=30, commission=0.001):
        print("[Backtest] Fetching " + str(days) + " days of " + symbol + " " + interval + " data...")
        limit = days * 24 if interval == "1h" else days * 24 * 60
        klines = self.client.get_klines(symbol, interval, min(limit, 1000))
        if not isinstance(klines, list) or len(klines) < 50:
            return {"error": "Insufficient data from Binance", "symbol": symbol}
        print("[Backtest] Loaded " + str(len(klines)) + " candles")
        closes = np.array([float(k[4]) for k in klines])
        highs = np.array([float(k[2]) for k in klines])
        lows = np.array([float(k[3]) for k in klines])
        volumes = np.array([float(k[5]) for k in klines])
        timestamps = [k[0] for k in klines]
        position = None
        self.equity_curve = [self.capital]
        for i in range(50, len(closes)):
            window_closes = closes[:i+1]
            window_highs = highs[:i+1]
            window_lows = lows[:i+1]
            window_volumes = volumes[:i+1]
            indicators = calculate_all_indicators(window_closes, window_highs, window_lows, window_volumes, self.config)
            current_price = closes[i]
            if position:
                pnl = 0
                exit_price = current_price
                exit_reason = ""
                if position["side"] == "LONG":
                    if current_price <= position["stop_loss"]:
                        pnl = (position["stop_loss"] - position["entry"]) * position["size"]
                        exit_price = position["stop_loss"]
                        exit_reason = "STOP_LOSS"
                    elif current_price >= position["take_profit"]:
                        pnl = (position["take_profit"] - position["entry"]) * position["size"]
                        exit_price = position["take_profit"]
                        exit_reason = "TAKE_PROFIT"
                    elif self.strategy.should_exit_trade(indicators, position["entry"], "LONG"):
                        pnl = (current_price - position["entry"]) * position["size"]
                        exit_reason = "STRATEGY"
                    else:
                        self.equity_curve.append(self.capital + (current_price - position["entry"]) * position["size"])
                        continue
                elif position["side"] == "SHORT":
                    if current_price >= position["stop_loss"]:
                        pnl = (position["entry"] - position["stop_loss"]) * position["size"]
                        exit_price = position["stop_loss"]
                        exit_reason = "STOP_LOSS"
                    elif current_price <= position["take_profit"]:
                        pnl = (position["entry"] - position["take_profit"]) * position["size"]
                        exit_price = position["take_profit"]
                        exit_reason = "TAKE_PROFIT"
                    elif self.strategy.should_exit_trade(indicators, position["entry"], "SHORT"):
                        pnl = (position["entry"] - current_price) * position["size"]
                        exit_reason = "STRATEGY"
                    else:
                        self.equity_curve.append(self.capital + (position["entry"] - current_price) * position["size"])
                        continue
                commission_cost = (position["entry"] + exit_price) * position["size"] * commission
                net_pnl = pnl - commission_cost
                self.capital += net_pnl
                if self.capital > self.peak:
                    self.peak = self.capital
                dd = (self.peak - self.capital) / self.peak
                if dd > self.max_drawdown:
                    self.max_drawdown = dd
                position["exit"] = exit_price
                position["pnl"] = net_pnl
                position["pnl_pct"] = (net_pnl / (position["entry"] * position["size"])) * 100
                position["exit_reason"] = exit_reason
                position["exit_time"] = timestamps[i]
                self.trades.append(position)
                position = None
                self.equity_curve.append(self.capital)
            elif self.strategy.should_enter_trade(indicators):
                signal = self.strategy.decide(indicators)
                trade_params = self.risk.validate_trade(signal, self.capital)
                if not trade_params["valid"]:
                    self.equity_curve.append(self.capital)
                    continue
                side = "LONG" if "BUY" in signal["signal"] else "SHORT"
                position = {
                    "side": side, "entry": trade_params["entry"],
                    "size": trade_params["size"],
                    "stop_loss": trade_params["stop_loss"],
                    "take_profit": trade_params["take_profit"],
                    "entry_time": timestamps[i],
                    "risk_reward": trade_params["risk_reward"]
                }
                self.equity_curve.append(self.capital)
            else:
                self.equity_curve.append(self.capital)
        return self._generate_report(symbol, interval, days)

    def _generate_report(self, symbol, interval, days):
        if not self.trades:
            return {"error": "No trades executed", "symbol": symbol, "period_days": days}
        pnls = [t["pnl"] for t in self.trades]
        winning_trades = [p for p in pnls if p > 0]
        losing_trades = [p for p in pnls if p <= 0]
        total_return = ((self.capital - self.config.INITIAL_CAPITAL) / self.config.INITIAL_CAPITAL) * 100
        if len(self.equity_curve) > 1:
            returns = np.diff(self.equity_curve) / self.equity_curve[:-1]
            sharpe = np.mean(returns) / np.std(returns) * np.sqrt(252) if np.std(returns) > 0 else 0
        else:
            sharpe = 0
        report = {
            "symbol": symbol, "interval": interval, "period_days": days,
            "initial_capital": self.config.INITIAL_CAPITAL,
            "final_capital": round(self.capital, 2),
            "total_return_pct": round(total_return, 2),
            "total_trades": len(self.trades),
            "winning_trades": len(winning_trades),
            "losing_trades": len(losing_trades),
            "win_rate": round(len(winning_trades) / len(self.trades) * 100, 2) if self.trades else 0,
            "avg_pnl": round(np.mean(pnls), 2),
            "avg_win": round(np.mean(winning_trades), 2) if winning_trades else 0,
            "avg_loss": round(np.mean(losing_trades), 2) if losing_trades else 0,
            "max_drawdown_pct": round(self.max_drawdown * 100, 2),
            "profit_factor": round(abs(sum(winning_trades) / sum(losing_trades)), 2) if losing_trades and sum(losing_trades) != 0 else float('inf'),
            "sharpe_ratio": round(sharpe, 2),
            "trades": self.trades
        }
        print("=" * 60)
        print("BACKTEST RESULTS: " + symbol + " (" + interval + ", " + str(days) + " days)")
        print("=" * 60)
        print("Initial Capital: $" + str(round(report["initial_capital"], 2)))
        print("Final Capital:   $" + str(round(report["final_capital"], 2)))
        print("Total Return:    " + str(round(report["total_return_pct"], 2)) + "%")
        print("Total Trades:    " + str(report["total_trades"]))
        print("Win Rate:        " + str(round(report["win_rate"], 1)) + "%")
        print("Max Drawdown:    " + str(round(report["max_drawdown_pct"], 2)) + "%")
        print("Sharpe Ratio:    " + str(round(report["sharpe_ratio"], 2)))
        print("Profit Factor:   " + str(round(report["profit_factor"], 2)))
        print("=" * 60)
        return report
