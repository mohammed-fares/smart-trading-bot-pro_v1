import asyncio
import numpy as np
import json
from datetime import datetime
from pathlib import Path

from config import Config
from binance_client import BinanceClient
from binance_ws import BinanceWebSocket
from strategy import StrategyEngine
from risk import RiskManager
from indicators import calculate_all_indicators
from telegram_bot import TelegramNotifier


class PaperTrade:
    def __init__(self, trade_id, symbol, side, entry, size, stop_loss, take_profit,
                 confidence, risk_reward, timestamp):
        self.id = trade_id
        self.symbol = symbol
        self.side = side
        self.entry = entry
        self.size = size
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        self.confidence = confidence
        self.risk_reward = risk_reward
        self.open_time = timestamp
        self.close_time = None
        self.exit_price = None
        self.exit_reason = None
        self.pnl = 0.0
        self.pnl_pct = 0.0
        self.status = "OPEN"

    def close(self, exit_price, reason, timestamp):
        self.exit_price = exit_price
        self.exit_reason = reason
        self.close_time = timestamp
        self.status = "CLOSED"
        if self.side == "BUY":
            self.pnl = (exit_price - self.entry) * self.size
        else:
            self.pnl = (self.entry - exit_price) * self.size
        self.pnl_pct = (self.pnl / (self.entry * self.size)) * 100
        return self.pnl

    def to_dict(self):
        return {
            "id": self.id, "symbol": self.symbol, "side": self.side,
            "entry": self.entry, "size": self.size,
            "stop_loss": self.stop_loss, "take_profit": self.take_profit,
            "confidence": self.confidence, "risk_reward": self.risk_reward,
            "open_time": self.open_time, "close_time": self.close_time,
            "exit_price": self.exit_price, "exit_reason": self.exit_reason,
            "pnl": round(self.pnl, 4), "pnl_pct": round(self.pnl_pct, 4),
            "status": self.status
        }


class TradingEngine:
    def __init__(self, config=None):
        self.config = config or Config()
        self.client = BinanceClient(self.config)
        self.strategy = StrategyEngine(self.config)
        self.risk = RiskManager(self.config)
        self.ws = BinanceWebSocket(self.config)
        self.telegram = TelegramNotifier(self.config)
        self.price_history = {}
        self.volume_history = {}
        self.high_history = {}
        self.low_history = {}
        self.active_trades = {}
        self.closed_trades = []
        self.trade_counter = 0
        self.current_capital = self.config.INITIAL_CAPITAL
        self.peak_capital = self.config.INITIAL_CAPITAL
        self.max_drawdown = 0.0
        self.is_running = False
        self.start_time = None
        self.stats_history = []
        self.log_file = Path("logs/trades.jsonl")
        self.log_file.parent.mkdir(exist_ok=True)

    async def start(self):
        self.is_running = True
        self.start_time = datetime.now()
        self.ws.add_price_callback(self._on_price_update)
        for symbol in self.config.TRADING_PAIRS:
            asyncio.create_task(self.ws.connect(symbol))
            await asyncio.sleep(0.5)
        asyncio.create_task(self._monitoring_loop())
        asyncio.create_task(self._stats_loop())
        mode = "PAPER TRADING" if self.config.PAPER_TRADING else "LIVE TRADING"
        lines = [
            "Trading Bot Started",
            "",
            "Mode: " + mode,
            "Capital: $" + str(round(self.config.INITIAL_CAPITAL, 2)),
            "Risk/Trade: " + str(self.config.RISK_PER_TRADE) + "%",
            "Pairs: " + ", ".join(self.config.TRADING_PAIRS)
        ]
        msg = "\n".join(lines)
        print("=" * 60)
        print(msg)
        print("=" * 60)
        await self.telegram.send_message(msg)

    async def _on_price_update(self, symbol, price):
        if symbol not in self.price_history:
            self.price_history[symbol] = []
        self.price_history[symbol].append(price)
        if len(self.price_history[symbol]) > 200:
            self.price_history[symbol].pop(0)

    async def _monitoring_loop(self):
        while self.is_running:
            try:
                for symbol in self.config.TRADING_PAIRS:
                    await self._analyze_symbol(symbol)
                    await asyncio.sleep(1)
                await asyncio.sleep(self.config.CHECK_INTERVAL)
            except Exception as e:
                print("[Engine] Monitoring error: " + str(e))
                await asyncio.sleep(5)

    async def _analyze_symbol(self, symbol):
        if symbol not in self.price_history or len(self.price_history[symbol]) < 50:
            return
        klines = self.client.get_klines(symbol, "1h", 100)
        if isinstance(klines, list) and len(klines) > 50:
            closes = np.array([float(k[4]) for k in klines])
            highs = np.array([float(k[2]) for k in klines])
            lows = np.array([float(k[3]) for k in klines])
            volumes = np.array([float(k[5]) for k in klines])
        else:
            closes = np.array(self.price_history[symbol])
            highs = lows = volumes = None
        indicators = calculate_all_indicators(closes, highs, lows, volumes, self.config)
        signal_data = self.strategy.decide(indicators)
        if symbol not in self.active_trades:
            await self._check_entry(symbol, signal_data, indicators)
        else:
            await self._check_exit(symbol, indicators)

    async def _check_entry(self, symbol, signal_data, indicators):
        if signal_data["signal"] not in ["BUY", "STRONG_BUY", "SELL", "STRONG_SELL"]:
            return
        trade_params = self.risk.validate_trade(signal_data, self.current_capital)
        if not trade_params["valid"]:
            return
        side = "BUY" if "BUY" in signal_data["signal"] else "SELL"
        await self._execute_paper_trade(symbol, side, trade_params, signal_data)

    async def _execute_paper_trade(self, symbol, side, trade_params, signal_data):
        self.trade_counter += 1
        trade_id = symbol + "_" + str(self.trade_counter)
        trade = PaperTrade(
            trade_id=trade_id, symbol=symbol, side=side,
            entry=trade_params["entry"], size=trade_params["size"],
            stop_loss=trade_params["stop_loss"], take_profit=trade_params["take_profit"],
            confidence=signal_data["confidence"], risk_reward=trade_params["risk_reward"],
            timestamp=datetime.now().isoformat()
        )
        self.active_trades[symbol] = trade
        self.risk.add_position(trade.to_dict())
        self._log_trade(trade.to_dict())
        print("=" * 50)
        print("PAPER TRADE OPENED")
        print("=" * 50)
        print("Symbol: " + symbol + " | Side: " + side)
        print("Entry: $" + str(round(trade.entry, 2)) + " | SL: $" + str(round(trade.stop_loss, 2)) + " | TP: $" + str(round(trade.take_profit, 2)))
        print("Size: " + str(trade.size) + " | R/R: " + str(trade.risk_reward) + ":1 | Confidence: " + str(trade.confidence) + "%")
        print("=" * 50)
        await self.telegram.send_trade_open(trade.to_dict())

    async def _check_exit(self, symbol, indicators):
        trade = self.active_trades[symbol]
        current_price = indicators["price"]
        exit_triggered = False
        exit_reason = ""
        exit_price = current_price
        if trade.side == "BUY":
            if current_price <= trade.stop_loss:
                exit_triggered = True
                exit_reason = "STOP_LOSS"
                exit_price = trade.stop_loss
            elif current_price >= trade.take_profit:
                exit_triggered = True
                exit_reason = "TAKE_PROFIT"
                exit_price = trade.take_profit
            elif self.strategy.should_exit_trade(indicators, trade.entry, "LONG"):
                exit_triggered = True
                exit_reason = "STRATEGY_EXIT"
        elif trade.side == "SELL":
            if current_price >= trade.stop_loss:
                exit_triggered = True
                exit_reason = "STOP_LOSS"
                exit_price = trade.stop_loss
            elif current_price <= trade.take_profit:
                exit_triggered = True
                exit_reason = "TAKE_PROFIT"
                exit_price = trade.take_profit
            elif self.strategy.should_exit_trade(indicators, trade.entry, "SHORT"):
                exit_triggered = True
                exit_reason = "STRATEGY_EXIT"
        if exit_triggered:
            await self._close_paper_trade(trade, exit_price, exit_reason)

    async def _close_paper_trade(self, trade, exit_price, reason):
        symbol = trade.symbol
        pnl = trade.close(exit_price, reason, datetime.now().isoformat())
        self.current_capital += pnl
        if self.current_capital > self.peak_capital:
            self.peak_capital = self.current_capital
        dd = ((self.peak_capital - self.current_capital) / self.peak_capital) * 100
        if dd > self.max_drawdown:
            self.max_drawdown = dd
        self.closed_trades.append(trade.to_dict())
        del self.active_trades[symbol]
        self.risk.close_position(trade.id, pnl)
        self._log_trade(trade.to_dict())
        emoji = "WIN" if pnl > 0 else "LOSS"
        print("=" * 50)
        print(emoji + " PAPER TRADE CLOSED")
        print("=" * 50)
        print("Symbol: " + symbol + " | Reason: " + reason)
        print("Entry: $" + str(round(trade.entry, 2)) + " | Exit: $" + str(round(exit_price, 2)))
        print("PnL: $" + str(round(pnl, 2)) + " (" + str(round(trade.pnl_pct, 2)) + "%)")
        print("Current Capital: $" + str(round(self.current_capital, 2)))
        print("Max Drawdown: " + str(round(self.max_drawdown, 2)) + "%")
        print("=" * 50)
        await self.telegram.send_trade_close(trade.to_dict())

    def _log_trade(self, trade_dict):
        try:
            with open(self.log_file, "a") as f:
                f.write(json.dumps(trade_dict) + "\n")
        except Exception as e:
            print("[Engine] Log error: " + str(e))

    async def _stats_loop(self):
        while self.is_running:
            await asyncio.sleep(300)
            stats = self.get_stats()
            self.stats_history.append(stats)
            print("[Stats] Capital: $" + str(round(stats["current_capital"], 2)) + " | " +
                  "PnL: $" + str(round(stats["total_pnl"], 2)) + " | " +
                  "Trades: " + str(stats["total_trades"]) + " | " +
                  "Win Rate: " + str(round(stats["win_rate"], 1)) + "%")

    def get_stats(self):
        total_pnl = self.current_capital - self.config.INITIAL_CAPITAL
        total_trades = len(self.closed_trades)
        winning = [t for t in self.closed_trades if t.get("pnl", 0) > 0]
        losing = [t for t in self.closed_trades if t.get("pnl", 0) <= 0]
        win_rate = (len(winning) / total_trades * 100) if total_trades > 0 else 0
        avg_win = np.mean([t["pnl"] for t in winning]) if winning else 0
        avg_loss = np.mean([t["pnl"] for t in losing]) if losing else 0
        return {
            "timestamp": datetime.now().isoformat(),
            "initial_capital": self.config.INITIAL_CAPITAL,
            "current_capital": round(self.current_capital, 2),
            "total_pnl": round(total_pnl, 2),
            "total_pnl_pct": round((total_pnl / self.config.INITIAL_CAPITAL) * 100, 2),
            "max_drawdown_pct": round(self.max_drawdown, 2),
            "total_trades": total_trades,
            "winning_trades": len(winning),
            "losing_trades": len(losing),
            "win_rate": round(win_rate, 2),
            "avg_win": round(avg_win, 2),
            "avg_loss": round(avg_loss, 2),
            "open_trades": len(self.active_trades),
            "active_trades": [t.to_dict() for t in self.active_trades.values()]
        }

    async def analyze(self, symbol=None):
        symbol = symbol or self.config.DEFAULT_SYMBOL
        klines = self.client.get_klines(symbol, "1h", 100)
        if not isinstance(klines, list) or len(klines) < 50:
            return {"error": "Insufficient data", "symbol": symbol}
        closes = np.array([float(k[4]) for k in klines])
        highs = np.array([float(k[2]) for k in klines])
        lows = np.array([float(k[3]) for k in klines])
        volumes = np.array([float(k[5]) for k in klines])
        indicators = calculate_all_indicators(closes, highs, lows, volumes, self.config)
        signal = self.strategy.decide(indicators)
        return {
            "symbol": symbol,
            "timestamp": datetime.now().isoformat(),
            "price": indicators["price"],
            "indicators": {
                "rsi": round(indicators["rsi"], 2),
                "ema_fast": round(indicators["ema_fast"], 2),
                "ema_slow": round(indicators["ema_slow"], 2),
                "trend": indicators["trend"],
                "volume_spike": indicators.get("volume_spike", False),
                "volume_ratio": round(indicators.get("volume_ratio", 1), 2),
                "atr": round(indicators.get("atr", 0), 2),
                "macd": round(indicators.get("macd", 0), 4),
                "macd_signal": round(indicators.get("macd_signal", 0), 4)
            },
            "signal": signal,
            "stats": self.get_stats(),
            "portfolio_risk": self.risk.get_portfolio_risk()
        }

    async def stop(self):
        self.is_running = False
        await self.ws.disconnect()
        for symbol, trade in list(self.active_trades.items()):
            current_price = self.ws.get_last_price(symbol) or trade.entry
            await self._close_paper_trade(trade, current_price, "ENGINE_STOP")
        final_stats = self.get_stats()
        print("=" * 60)
        print("TRADING BOT STOPPED")
        print("=" * 60)
        print("Final Capital: $" + str(round(final_stats["current_capital"], 2)))
        print("Total PnL: $" + str(round(final_stats["total_pnl"], 2)) + " (" + str(round(final_stats["total_pnl_pct"], 2)) + "%)")
        print("Total Trades: " + str(final_stats["total_trades"]))
        print("Win Rate: " + str(round(final_stats["win_rate"], 1)) + "%")
        print("Max Drawdown: " + str(round(final_stats["max_drawdown_pct"], 2)) + "%")
        print("=" * 60)
        lines = [
            "Trading Bot Stopped",
            "",
            "Final Capital: $" + str(round(final_stats["current_capital"], 2)),
            "Total PnL: $" + str(round(final_stats["total_pnl"], 2)) + " (" + str(round(final_stats["total_pnl_pct"], 2)) + "%)",
            "Total Trades: " + str(final_stats["total_trades"]),
            "Win Rate: " + str(round(final_stats["win_rate"], 1)) + "%"
        ]
        await self.telegram.send_message("\n".join(lines))
