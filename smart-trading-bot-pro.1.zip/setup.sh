#!/bin/bash
# Smart Trading Bot Pro - Setup Script for Kali Linux

echo "=========================================="
echo "  Smart Trading Bot Pro - Setup"
echo "=========================================="

# Check if we're in the right directory
if [ ! -f "requirements.txt" ]; then
    echo "Error: requirements.txt not found!"
    echo "Please run this script from the project directory."
    exit 1
fi

# Step 1: Install system dependencies via apt
echo ""
echo "[1/5] Installing system dependencies..."
sudo apt update
sudo apt install -y python3-venv python3-pip python3-full

# Step 2: Create virtual environment
echo ""
echo "[2/5] Creating Python virtual environment..."
python3 -m venv venv

# Step 3: Activate venv and install packages
echo ""
echo "[3/5] Installing Python packages..."
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Step 4: Create run script
echo ""
echo "[4/5] Creating run script..."
cat > run.sh << 'EOF'
#!/bin/bash
# Run Smart Trading Bot Pro

if [ ! -d "venv" ]; then
    echo "Virtual environment not found! Run ./setup.sh first."
    exit 1
fi

source venv/bin/activate
echo "Starting Smart Trading Bot Pro..."
echo "Dashboard: http://localhost:8000/dashboard"
echo "API Docs:  http://localhost:8000/docs"
echo "Press Ctrl+C to stop"
echo ""
uvicorn main:app --reload --host 0.0.0.0 --port 8000
EOF
chmod +x run.sh

# Step 5: Create backtest script
cat > backtest.sh << 'EOF'
#!/bin/bash
# Run backtest via curl

if [ -z "$1" ]; then
    SYMBOL="BTCUSDT"
else
    SYMBOL="$1"
fi

if [ -z "$2" ]; then
    DAYS=30
else
    DAYS="$2"
fi

echo "Running backtest for $SYMBOL ($DAYS days)..."
curl "http://localhost:8000/backtest?symbol=$SYMBOL&days=$DAYS"
echo ""
EOF
chmod +x backtest.sh

# Step 6: Create quick test
echo ""
echo "[5/5] Testing installation..."
source venv/bin/activate
python3 -c "import fastapi, uvicorn, websockets, numpy, aiohttp, requests; print('All packages installed successfully!')"

echo ""
echo "=========================================="
echo "  Setup Complete!"
echo "=========================================="
echo ""
echo "To start the bot:"
echo "  ./run.sh"
echo ""
echo "To run backtest:"
echo "  ./backtest.sh BTCUSDT 30"
echo ""
echo "Dashboard: http://localhost:8000/dashboard"
echo "API Docs:  http://localhost:8000/docs"
echo ""
