import json
import os
from pathlib import Path

SETTINGS_FILE = Path("data/settings.json")

def get_settings():
    """Load settings from file or return defaults"""
    if SETTINGS_FILE.exists():
        try:
            with open(SETTINGS_FILE, "r") as f:
                return json.load(f)
        except:
            pass
    return get_default_settings()

def get_default_settings():
    """Return default settings matching config.py"""
    return {
        "initial_capital": 10000.0,
        "risk_per_trade": 1.0,
        "max_positions": 5,
        "leverage": 1,
        "paper_trading": True,
        "ema_fast": 9,
        "ema_slow": 21,
        "rsi_period": 14,
        "rsi_oversold": 30.0,
        "rsi_overbought": 70.0,
        "volume_spike_threshold": 2.0,
        "min_risk_reward": 1.5,
        "check_interval": 10,
        "trading_pairs": ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "ADAUSDT"],
        "default_symbol": "BTCUSDT",
        "stop_loss_multiplier": 2.0,
        "take_profit_multiplier": 3.0,
        "confidence_threshold": 45,
        "max_daily_loss_pct": 5.0,
        "max_daily_trades": 20,
        "commission_rate": 0.001,
        "telegram_enabled": False,
        "telegram_bot_token": "",
        "telegram_chat_id": "",
        "binance_api_key": "",
        "binance_secret_key": "",
    }

def save_settings(settings: dict):
    """Save settings to file"""
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f, indent=2)
    return settings

def apply_settings_to_config(settings: dict, config):
    """Apply loaded settings to a Config instance"""
    config.INITIAL_CAPITAL = float(settings.get("initial_capital", 10000.0))
    config.RISK_PER_TRADE = float(settings.get("risk_per_trade", 1.0))
    config.MAX_POSITIONS = int(settings.get("max_positions", 5))
    config.LEVERAGE = int(settings.get("leverage", 1))
    config.PAPER_TRADING = bool(settings.get("paper_trading", True))
    config.EMA_FAST = int(settings.get("ema_fast", 9))
    config.EMA_SLOW = int(settings.get("ema_slow", 21))
    config.RSI_PERIOD = int(settings.get("rsi_period", 14))
    config.RSI_OVERSOLD = float(settings.get("rsi_oversold", 30.0))
    config.RSI_OVERBOUGHT = float(settings.get("rsi_overbought", 70.0))
    config.VOLUME_SPIKE_THRESHOLD = float(settings.get("volume_spike_threshold", 2.0))
    config.MIN_RISK_REWARD = float(settings.get("min_risk_reward", 1.5))
    config.CHECK_INTERVAL = int(settings.get("check_interval", 10))
    config.TRADING_PAIRS = list(settings.get("trading_pairs", ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "ADAUSDT"]))
    config.DEFAULT_SYMBOL = str(settings.get("default_symbol", "BTCUSDT"))
    config.TELEGRAM_BOT_TOKEN = str(settings.get("telegram_bot_token", ""))
    config.TELEGRAM_CHAT_ID = str(settings.get("telegram_chat_id", ""))
    config.BINANCE_API_KEY = str(settings.get("binance_api_key", ""))
    config.BINANCE_SECRET_KEY = str(settings.get("binance_secret_key", ""))
    return config
