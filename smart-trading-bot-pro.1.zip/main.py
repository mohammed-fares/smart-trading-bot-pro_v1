import asyncio
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse
from contextlib import asynccontextmanager

from config import Config
from engine import TradingEngine
from backtest import BacktestEngine
from settings_page import get_settings, save_settings, apply_settings_to_config

engine = TradingEngine()
backtest_engine = BacktestEngine()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Load settings before starting
    settings = get_settings()
    apply_settings_to_config(settings, engine.config)
    await engine.start()
    yield
    await engine.stop()

app = FastAPI(
    title="Smart Trading Bot Pro",
    description="Professional Paper Trading Bot with Real Binance Data",
    version="2.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def home():
    return {
        "status": "running",
        "bot": "Smart Trading Bot Pro v2.0",
        "mode": "PAPER TRADING",
        "features": [
            "Real-time Binance WebSocket",
            "Technical Indicators (RSI, EMA, MACD, Bollinger, ATR)",
            "Advanced Risk Management",
            "Automatic Trade Execution and Closure",
            "Paper Trading (Simulated)",
            "Backtesting with Real Data",
            "Telegram Alerts",
            "Performance Tracking",
            "Web-based Settings Configuration"
        ]
    }

@app.get("/analyze")
async def analyze(symbol: str = "BTCUSDT"):
    return await engine.analyze(symbol)

@app.get("/backtest")
async def backtest(symbol: str = "BTCUSDT", days: int = 30, interval: str = "1h"):
    return backtest_engine.run(symbol, interval, days)

@app.get("/stats")
async def stats():
    return engine.get_stats()

@app.get("/trades")
async def trades(limit: int = 100):
    all_trades = [t.to_dict() for t in engine.active_trades.values()]
    all_trades.extend(engine.closed_trades[-limit:])
    return {
        "trades": all_trades,
        "open_count": len(engine.active_trades),
        "closed_count": len(engine.closed_trades)
    }

@app.get("/dashboard")
async def dashboard():
    stats = engine.get_stats()
    pnl_class = "green" if stats["total_pnl"] >= 0 else "red"

    active_rows = ""
    for t in stats["active_trades"]:
        active_rows += "<tr><td>" + t["symbol"] + "</td><td>" + t["side"] + "</td><td>$" + str(round(t["entry"], 2)) + "</td><td>-</td><td>$" + str(round(t["stop_loss"], 2)) + "</td><td>$" + str(round(t["take_profit"], 2)) + "</td><td>OPEN</td></tr>"

    closed_rows = ""
    for t in engine.closed_trades[-10:]:
        pnl_class_row = "green" if t.get("pnl", 0) > 0 else "red"
        closed_rows += "<tr><td>" + t["symbol"] + "</td><td>" + t["side"] + "</td><td>$" + str(round(t["entry"], 2)) + "</td><td>$" + str(round(t.get("exit_price", 0), 2)) + "</td><td>" + t.get("exit_reason", "") + "</td><td class=\"" + pnl_class_row + "\">$" + str(round(t.get("pnl", 0), 2)) + "</td></tr>"

    html = """<!DOCTYPE html>
<html>
<head>
<title>Smart Trading Bot Pro - Live Dashboard</title>
<style>
body { font-family: 'Segoe UI', Arial, sans-serif; background: #0a0e27; color: #fff; padding: 20px; margin: 0; }
.card { background: linear-gradient(135deg, #1a1f3a 0%, #252b4d 100%); border-radius: 12px; padding: 20px; margin: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.3); border: 1px solid #2a3050; }
.green { color: #00d084; } .red { color: #ff4757; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; }
h1 { text-align: center; color: #00d084; margin-bottom: 5px; }
.subtitle { text-align: center; color: #8892b0; margin-bottom: 20px; font-size: 14px; }
.value { font-size: 28px; font-weight: bold; margin-top: 8px; }
.label { color: #8892b0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; }
table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 14px; }
th, td { padding: 12px 10px; text-align: left; border-bottom: 1px solid #2a3050; }
th { color: #00d084; font-weight: 600; background: #1a1f3a; }
tr:hover { background: #1a1f3a; }
.status-bar { background: #1a1f3a; padding: 10px 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
.status-indicator { display: inline-block; width: 10px; height: 10px; background: #00d084; border-radius: 50%; animation: pulse 2s infinite; }
@keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.4; } 100% { opacity: 1; } }
.refresh-info { color: #8892b0; font-size: 12px; }
.section-title { color: #00d084; font-size: 18px; margin: 25px 0 10px 0; font-weight: 600; }
.no-data { color: #8892b0; text-align: center; padding: 20px; }
.nav { text-align: center; margin-bottom: 20px; }
.nav a { color: #00d084; text-decoration: none; padding: 10px 20px; border: 1px solid #00d084; border-radius: 6px; margin: 0 5px; display: inline-block; }
.nav a:hover { background: #00d084; color: #0a0e27; }
</style>
</head>
<body>
<div class="nav">
<a href="/dashboard">Dashboard</a>
<a href="/settings">Settings</a>
<a href="/docs">API Docs</a>
</div>

<div class="status-bar">
<div><span class="status-indicator"></span> <strong>Bot Running</strong> | Paper Trading Mode</div>
<div class="refresh-info">Auto-refresh every 10 seconds | Last update: """ + stats["timestamp"] + """</div>
</div>

<h1>Smart Trading Bot Pro</h1>
<div class="subtitle">Real-time Paper Trading Dashboard with Binance Data</div>

<div class="grid">
<div class="card">
<div class="label">Current Capital</div>
<div class="value">$""" + str(round(stats["current_capital"], 2)) + """</div>
</div>
<div class="card">
<div class="label">Total PnL</div>
<div class="value """ + pnl_class + """">$""" + str(round(stats["total_pnl"], 2)) + " (" + str(round(stats["total_pnl_pct"], 2)) + """%)</div>
</div>
<div class="card">
<div class="label">Total Trades</div>
<div class="value">""" + str(stats["total_trades"]) + """</div>
</div>
<div class="card">
<div class="label">Win Rate</div>
<div class="value">""" + str(round(stats["win_rate"], 1)) + """%</div>
</div>
<div class="card">
<div class="label">Open Trades</div>
<div class="value">""" + str(stats["open_trades"]) + """</div>
</div>
<div class="card">
<div class="label">Max Drawdown</div>
<div class="value red">""" + str(round(stats["max_drawdown_pct"], 2)) + """%</div>
</div>
<div class="card">
<div class="label">Winning Trades</div>
<div class="value green">""" + str(stats["winning_trades"]) + """</div>
</div>
<div class="card">
<div class="label">Losing Trades</div>
<div class="value red">""" + str(stats["losing_trades"]) + """</div>
</div>
</div>

<div class="section-title">Active Trades</div>
<table>
<tr><th>Symbol</th><th>Side</th><th>Entry</th><th>Current</th><th>Stop Loss</th><th>Take Profit</th><th>Status</th></tr>
""" + (active_rows if active_rows else "<tr><td colspan=7 class=no-data>No active trades</td></tr>") + """
</table>

<div class="section-title">Recent Closed Trades</div>
<table>
<tr><th>Symbol</th><th>Side</th><th>Entry</th><th>Exit</th><th>Reason</th><th>PnL</th></tr>
""" + (closed_rows if closed_rows else "<tr><td colspan=6 class=no-data>No closed trades yet</td></tr>") + """
</table>

<script>
setInterval(function() {
    window.location.reload();
}, 10000);
let seconds = 10;
setInterval(function() {
    seconds--;
    if (seconds < 0) seconds = 10;
    document.title = "Smart Trading Bot Pro - Refresh in " + seconds + "s";
}, 1000);
</script>
</body>
</html>"""
    return HTMLResponse(content=html)

@app.get("/settings")
async def settings_page():
    """Settings configuration page"""
    s = get_settings()

    pairs_str = ", ".join(s.get("trading_pairs", []))
    paper_checked = "checked" if s.get("paper_trading", True) else ""
    telegram_checked = "checked" if s.get("telegram_enabled", False) else ""

    html = """<!DOCTYPE html>
<html>
<head>
<title>Smart Trading Bot Pro - Settings</title>
<style>
body { font-family: 'Segoe UI', Arial, sans-serif; background: #0a0e27; color: #fff; padding: 20px; margin: 0; }
h1 { text-align: center; color: #00d084; margin-bottom: 5px; }
.subtitle { text-align: center; color: #8892b0; margin-bottom: 30px; font-size: 14px; }
.nav { text-align: center; margin-bottom: 20px; }
.nav a { color: #00d084; text-decoration: none; padding: 10px 20px; border: 1px solid #00d084; border-radius: 6px; margin: 0 5px; display: inline-block; }
.nav a:hover { background: #00d084; color: #0a0e27; }
.form-container { max-width: 900px; margin: 0 auto; }
.section { background: linear-gradient(135deg, #1a1f3a 0%, #252b4d 100%); border-radius: 12px; padding: 25px; margin-bottom: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.3); border: 1px solid #2a3050; }
.section-title { color: #00d084; font-size: 18px; margin-bottom: 20px; font-weight: 600; border-bottom: 2px solid #00d084; padding-bottom: 10px; }
.form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 15px; }
.form-group { display: flex; flex-direction: column; }
label { color: #8892b0; font-size: 13px; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px; }
input[type="text"], input[type="number"], select, textarea {
    background: #0a0e27; border: 1px solid #2a3050; color: #fff; padding: 10px 12px;
    border-radius: 6px; font-size: 14px; transition: border-color 0.3s;
}
input:focus, select:focus, textarea:focus { border-color: #00d084; outline: none; }
input[type="checkbox"] { width: 20px; height: 20px; accent-color: #00d084; }
.checkbox-group { flex-direction: row; align-items: center; gap: 10px; }
.checkbox-group label { margin-bottom: 0; }
.help-text { color: #5a6278; font-size: 11px; margin-top: 4px; }
.btn-save {
    background: linear-gradient(135deg, #00d084 0%, #00a86b 100%);
    color: #0a0e27; border: none; padding: 14px 40px; font-size: 16px;
    font-weight: bold; border-radius: 8px; cursor: pointer;
    display: block; margin: 30px auto 0; transition: transform 0.2s;
}
.btn-save:hover { transform: scale(1.05); }
.alert {
    background: linear-gradient(135deg, #00d084 0%, #00a86b 100%);
    color: #0a0e27; padding: 15px 20px; border-radius: 8px;
    text-align: center; font-weight: bold; margin-bottom: 20px;
}
.alert-error { background: linear-gradient(135deg, #ff4757 0%, #cc0033 100%); color: #fff; }
</style>
</head>
<body>
<div class="nav">
<a href="/dashboard">Dashboard</a>
<a href="/settings">Settings</a>
<a href="/docs">API Docs</a>
</div>

<h1>Trading Bot Settings</h1>
<div class="subtitle">Configure all trading parameters - Changes apply on next bot restart</div>

<div class="form-container">
<form action="/settings/save" method="post">

<div class="section">
<div class="section-title">Trading Mode</div>
<div class="form-row">
<div class="form-group checkbox-group">
<input type="checkbox" id="paper_trading" name="paper_trading" value="true" """ + paper_checked + """>
<label for="paper_trading">Paper Trading Mode (Simulated)</label>
</div>
<div class="form-group checkbox-group">
<input type="checkbox" id="telegram_enabled" name="telegram_enabled" value="true" """ + telegram_checked + """>
<label for="telegram_enabled">Enable Telegram Notifications</label>
</div>
</div>
<div class="help-text">Paper Trading = simulated trades with real data. Uncheck for LIVE trading (requires API keys).</div>
</div>

<div class="section">
<div class="section-title">Capital & Risk</div>
<div class="form-row">
<div class="form-group">
<label>Initial Capital ($)</label>
<input type="number" name="initial_capital" value=""" + str(s.get("initial_capital", 10000)) + """ step="100" min="100">
<div class="help-text">Starting balance for paper trading</div>
</div>
<div class="form-group">
<label>Risk Per Trade (%)</label>
<input type="number" name="risk_per_trade" value=""" + str(s.get("risk_per_trade", 1.0)) + """ step="0.1" min="0.1" max="100">
<div class="help-text">Percentage of capital risked per trade</div>
</div>
<div class="form-group">
<label>Max Positions</label>
<input type="number" name="max_positions" value=""" + str(s.get("max_positions", 5)) + """ step="1" min="1" max="20">
<div class="help-text">Maximum number of open trades</div>
</div>
<div class="form-group">
<label>Leverage</label>
<input type="number" name="leverage" value=""" + str(s.get("leverage", 1)) + """ step="1" min="1" max="125">
<div class="help-text">Futures leverage (1 = spot)</div>
</div>
</div>
<div class="form-row">
<div class="form-group">
<label>Max Daily Loss (%)</label>
<input type="number" name="max_daily_loss_pct" value=""" + str(s.get("max_daily_loss_pct", 5.0)) + """ step="0.5" min="0.5" max="100">
<div class="help-text">Stop trading after this daily loss</div>
</div>
<div class="form-group">
<label>Max Daily Trades</label>
<input type="number" name="max_daily_trades" value=""" + str(s.get("max_daily_trades", 20)) + """ step="1" min="1" max="100">
<div class="help-text">Maximum trades per day</div>
</div>
<div class="form-group">
<label>Commission Rate</label>
<input type="number" name="commission_rate" value=""" + str(s.get("commission_rate", 0.001)) + """ step="0.0001" min="0" max="0.01">
<div class="help-text">Trading fee per trade (0.001 = 0.1%)</div>
</div>
</div>
</div>

<div class="section">
<div class="section-title">Stop Loss & Take Profit</div>
<div class="form-row">
<div class="form-group">
<label>Stop Loss Multiplier (x ATR)</label>
<input type="number" name="stop_loss_multiplier" value=""" + str(s.get("stop_loss_multiplier", 2.0)) + """ step="0.1" min="0.5" max="10">
<div class="help-text">SL = Entry +/- (Multiplier * ATR)</div>
</div>
<div class="form-group">
<label>Take Profit Multiplier (x ATR)</label>
<input type="number" name="take_profit_multiplier" value=""" + str(s.get("take_profit_multiplier", 3.0)) + """ step="0.1" min="0.5" max="20">
<div class="help-text">TP = Entry +/- (Multiplier * ATR)</div>
</div>
<div class="form-group">
<label>Min Risk/Reward Ratio</label>
<input type="number" name="min_risk_reward" value=""" + str(s.get("min_risk_reward", 1.5)) + """ step="0.1" min="0.5" max="10">
<div class="help-text">Minimum R/R to enter trade</div>
</div>
</div>
</div>

<div class="section">
<div class="section-title">Strategy Indicators</div>
<div class="form-row">
<div class="form-group">
<label>EMA Fast Period</label>
<input type="number" name="ema_fast" value=""" + str(s.get("ema_fast", 9)) + """ step="1" min="2" max="100">
</div>
<div class="form-group">
<label>EMA Slow Period</label>
<input type="number" name="ema_slow" value=""" + str(s.get("ema_slow", 21)) + """ step="1" min="2" max="200">
</div>
<div class="form-group">
<label>RSI Period</label>
<input type="number" name="rsi_period" value=""" + str(s.get("rsi_period", 14)) + """ step="1" min="2" max="50">
</div>
</div>
<div class="form-row">
<div class="form-group">
<label>RSI Oversold Level</label>
<input type="number" name="rsi_oversold" value=""" + str(s.get("rsi_oversold", 30.0)) + """ step="1" min="0" max="50">
</div>
<div class="form-group">
<label>RSI Overbought Level</label>
<input type="number" name="rsi_overbought" value=""" + str(s.get("rsi_overbought", 70.0)) + """ step="1" min="50" max="100">
</div>
<div class="form-group">
<label>Volume Spike Threshold (x)</label>
<input type="number" name="volume_spike_threshold" value=""" + str(s.get("volume_spike_threshold", 2.0)) + """ step="0.1" min="1" max="10">
<div class="help-text">Volume must exceed avg by this multiple</div>
</div>
</div>
<div class="form-row">
<div class="form-group">
<label>Confidence Threshold (%)</label>
<input type="number" name="confidence_threshold" value=""" + str(s.get("confidence_threshold", 45)) + """ step="1" min="10" max="100">
<div class="help-text">Min confidence to enter trade</div>
</div>
</div>
</div>

<div class="section">
<div class="section-title">Trading Pairs & Timing</div>
<div class="form-row">
<div class="form-group">
<label>Default Symbol</label>
<input type="text" name="default_symbol" value=""" + str(s.get("default_symbol", "BTCUSDT")) + """>
</div>
<div class="form-group">
<label>Trading Pairs (comma-separated)</label>
<textarea name="trading_pairs" rows="2">""" + pairs_str + """</textarea>
<div class="help-text">Symbols to monitor for trades</div>
</div>
<div class="form-group">
<label>Check Interval (seconds)</label>
<input type="number" name="check_interval" value=""" + str(s.get("check_interval", 10)) + """ step="1" min="5" max="300">
<div class="help-text">How often to check for signals</div>
</div>
</div>
</div>

<div class="section">
<div class="section-title">API Keys (Optional)</div>
<div class="form-row">
<div class="form-group">
<label>Binance API Key</label>
<input type="text" name="binance_api_key" value=""" + str(s.get("binance_api_key", "")) + """ placeholder="Leave empty for public data only">
</div>
<div class="form-group">
<label>Binance Secret Key</label>
<input type="text" name="binance_secret_key" value=""" + str(s.get("binance_secret_key", "")) + """ placeholder="Leave empty for public data only">
</div>
</div>
<div class="form-row">
<div class="form-group">
<label>Telegram Bot Token</label>
<input type="text" name="telegram_bot_token" value=""" + str(s.get("telegram_bot_token", "")) + """ placeholder="Get from @BotFather">
</div>
<div class="form-group">
<label>Telegram Chat ID</label>
<input type="text" name="telegram_chat_id" value=""" + str(s.get("telegram_chat_id", "")) + """ placeholder="Your Telegram user ID">
</div>
</div>
</div>

<button type="submit" class="btn-save">Save Settings</button>
</form>
</div>

</body>
</html>"""
    return HTMLResponse(content=html)

@app.post("/settings/save")
async def settings_save(
    initial_capital: float = Form(10000.0),
    risk_per_trade: float = Form(1.0),
    max_positions: int = Form(5),
    leverage: int = Form(1),
    paper_trading: str = Form("false"),
    ema_fast: int = Form(9),
    ema_slow: int = Form(21),
    rsi_period: int = Form(14),
    rsi_oversold: float = Form(30.0),
    rsi_overbought: float = Form(70.0),
    volume_spike_threshold: float = Form(2.0),
    min_risk_reward: float = Form(1.5),
    check_interval: int = Form(10),
    trading_pairs: str = Form("BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,ADAUSDT"),
    default_symbol: str = Form("BTCUSDT"),
    stop_loss_multiplier: float = Form(2.0),
    take_profit_multiplier: float = Form(3.0),
    confidence_threshold: float = Form(45),
    max_daily_loss_pct: float = Form(5.0),
    max_daily_trades: int = Form(20),
    commission_rate: float = Form(0.001),
    telegram_enabled: str = Form("false"),
    telegram_bot_token: str = Form(""),
    telegram_chat_id: str = Form(""),
    binance_api_key: str = Form(""),
    binance_secret_key: str = Form(""),
):
    """Save settings to file"""
    pairs = [p.strip().upper() for p in trading_pairs.split(",") if p.strip()]

    settings = {
        "initial_capital": initial_capital,
        "risk_per_trade": risk_per_trade,
        "max_positions": max_positions,
        "leverage": leverage,
        "paper_trading": paper_trading.lower() in ("true", "on", "1", "yes"),
        "ema_fast": ema_fast,
        "ema_slow": ema_slow,
        "rsi_period": rsi_period,
        "rsi_oversold": rsi_oversold,
        "rsi_overbought": rsi_overbought,
        "volume_spike_threshold": volume_spike_threshold,
        "min_risk_reward": min_risk_reward,
        "check_interval": check_interval,
        "trading_pairs": pairs,
        "default_symbol": default_symbol,
        "stop_loss_multiplier": stop_loss_multiplier,
        "take_profit_multiplier": take_profit_multiplier,
        "confidence_threshold": confidence_threshold,
        "max_daily_loss_pct": max_daily_loss_pct,
        "max_daily_trades": max_daily_trades,
        "commission_rate": commission_rate,
        "telegram_enabled": telegram_enabled.lower() in ("true", "on", "1", "yes"),
        "telegram_bot_token": telegram_bot_token,
        "telegram_chat_id": telegram_chat_id,
        "binance_api_key": binance_api_key,
        "binance_secret_key": binance_secret_key,
    }

    save_settings(settings)

    # Apply to running config
    apply_settings_to_config(settings, engine.config)

    return HTMLResponse(content="""<!DOCTYPE html>
<html>
<head>
<title>Settings Saved</title>
<style>
body { font-family: 'Segoe UI', Arial, sans-serif; background: #0a0e27; color: #fff; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
.card { background: linear-gradient(135deg, #1a1f3a 0%, #252b4d 100%); border-radius: 16px; padding: 40px; text-align: center; box-shadow: 0 8px 30px rgba(0,0,0,0.4); border: 1px solid #2a3050; }
h1 { color: #00d084; margin-bottom: 15px; }
p { color: #8892b0; margin-bottom: 30px; }
a { display: inline-block; background: #00d084; color: #0a0e27; padding: 12px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; margin: 5px; }
a:hover { background: #00ff9d; }
</style>
</head>
<body>
<div class="card">
<h1>Settings Saved Successfully!</h1>
<p>Your trading configuration has been updated.</p>
<a href="/settings">Back to Settings</a>
<a href="/dashboard">Go to Dashboard</a>
</div>
</body>
</html>""")

@app.websocket("/ws")
async def ws_endpoint(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            data = await engine.analyze()
            await websocket.send_json(data)
            await asyncio.sleep(2)
    except WebSocketDisconnect:
        print("Client disconnected")
    except Exception as e:
        print("WebSocket error: " + str(e))

@app.websocket("/ws/price/{symbol}")
async def price_ws(websocket: WebSocket, symbol: str):
    await websocket.accept()
    async def price_callback(sym, price):
        await websocket.send_json({"symbol": sym, "price": price, "time": asyncio.get_event_loop().time()})
    engine.ws.add_price_callback(price_callback)
    try:
        while True:
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        print("Price WS disconnected for " + symbol)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
